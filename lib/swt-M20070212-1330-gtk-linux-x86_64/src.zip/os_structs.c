/*******************************************************************************
 * Copyright (c) 2000, 2006 IBM Corporation and others. All rights reserved.
 * The contents of this file are made available under the terms
 * of the GNU Lesser General Public License (LGPL) Version 2.1 that
 * accompanies this distribution (lgpl-v21.txt).  The LGPL is also
 * available at http://www.gnu.org/licenses/lgpl.html.  If the version
 * of the LGPL at http://www.gnu.org is different to the version of
 * the LGPL accompanying this distribution and there is any conflict
 * between the two license versions, the terms of the LGPL accompanying
 * this distribution shall govern.
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

#include "swt.h"
#include "os_structs.h"

#ifndef NO_GInterfaceInfo
typedef struct GInterfaceInfo_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID interface_data, interface_finalize, interface_init;
} GInterfaceInfo_FID_CACHE;

GInterfaceInfo_FID_CACHE GInterfaceInfoFc;

void cacheGInterfaceInfoFields(JNIEnv *env, jobject lpObject)
{
	if (GInterfaceInfoFc.cached) return;
	GInterfaceInfoFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GInterfaceInfoFc.interface_data = (*env)->GetFieldID(env, GInterfaceInfoFc.clazz, "interface_data", "J");
	GInterfaceInfoFc.interface_finalize = (*env)->GetFieldID(env, GInterfaceInfoFc.clazz, "interface_finalize", "J");
	GInterfaceInfoFc.interface_init = (*env)->GetFieldID(env, GInterfaceInfoFc.clazz, "interface_init", "J");
	GInterfaceInfoFc.cached = 1;
}

GInterfaceInfo *getGInterfaceInfoFields(JNIEnv *env, jobject lpObject, GInterfaceInfo *lpStruct)
{
	if (!GInterfaceInfoFc.cached) cacheGInterfaceInfoFields(env, lpObject);
	lpStruct->interface_data = (gpointer)(*env)->GetLongField(env, lpObject, GInterfaceInfoFc.interface_data);
	lpStruct->interface_finalize = (GInterfaceFinalizeFunc)(*env)->GetLongField(env, lpObject, GInterfaceInfoFc.interface_finalize);
	lpStruct->interface_init = (GInterfaceInitFunc)(*env)->GetLongField(env, lpObject, GInterfaceInfoFc.interface_init);
	return lpStruct;
}

void setGInterfaceInfoFields(JNIEnv *env, jobject lpObject, GInterfaceInfo *lpStruct)
{
	if (!GInterfaceInfoFc.cached) cacheGInterfaceInfoFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GInterfaceInfoFc.interface_data, (jlong)lpStruct->interface_data);
	(*env)->SetLongField(env, lpObject, GInterfaceInfoFc.interface_finalize, (jlong)lpStruct->interface_finalize);
	(*env)->SetLongField(env, lpObject, GInterfaceInfoFc.interface_init, (jlong)lpStruct->interface_init);
}
#endif

#ifndef NO_GObjectClass
typedef struct GObjectClass_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID notify, dispatch_properties_changed, finalize, dispose, get_property, set_property, constructor;
} GObjectClass_FID_CACHE;

GObjectClass_FID_CACHE GObjectClassFc;

void cacheGObjectClassFields(JNIEnv *env, jobject lpObject)
{
	if (GObjectClassFc.cached) return;
	GObjectClassFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GObjectClassFc.notify = (*env)->GetFieldID(env, GObjectClassFc.clazz, "notify", "J");
	GObjectClassFc.dispatch_properties_changed = (*env)->GetFieldID(env, GObjectClassFc.clazz, "dispatch_properties_changed", "J");
	GObjectClassFc.finalize = (*env)->GetFieldID(env, GObjectClassFc.clazz, "finalize", "J");
	GObjectClassFc.dispose = (*env)->GetFieldID(env, GObjectClassFc.clazz, "dispose", "J");
	GObjectClassFc.get_property = (*env)->GetFieldID(env, GObjectClassFc.clazz, "get_property", "J");
	GObjectClassFc.set_property = (*env)->GetFieldID(env, GObjectClassFc.clazz, "set_property", "J");
	GObjectClassFc.constructor = (*env)->GetFieldID(env, GObjectClassFc.clazz, "constructor", "J");
	GObjectClassFc.cached = 1;
}

GObjectClass *getGObjectClassFields(JNIEnv *env, jobject lpObject, GObjectClass *lpStruct)
{
	if (!GObjectClassFc.cached) cacheGObjectClassFields(env, lpObject);
	lpStruct->notify = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.notify);
	lpStruct->dispatch_properties_changed = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.dispatch_properties_changed);
	lpStruct->finalize = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.finalize);
	lpStruct->dispose = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.dispose);
	lpStruct->get_property = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.get_property);
	lpStruct->set_property = (void (*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.set_property);
	lpStruct->constructor = (GObject *(*)())(*env)->GetLongField(env, lpObject, GObjectClassFc.constructor);
	return lpStruct;
}

void setGObjectClassFields(JNIEnv *env, jobject lpObject, GObjectClass *lpStruct)
{
	if (!GObjectClassFc.cached) cacheGObjectClassFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.notify, (jlong)lpStruct->notify);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.dispatch_properties_changed, (jlong)lpStruct->dispatch_properties_changed);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.finalize, (jlong)lpStruct->finalize);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.dispose, (jlong)lpStruct->dispose);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.get_property, (jlong)lpStruct->get_property);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.set_property, (jlong)lpStruct->set_property);
	(*env)->SetLongField(env, lpObject, GObjectClassFc.constructor, (jlong)lpStruct->constructor);
}
#endif

#ifndef NO_GTypeInfo
typedef struct GTypeInfo_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID value_table, instance_init, n_preallocs, instance_size, class_data, class_finalize, class_init, base_finalize, base_init, class_size;
} GTypeInfo_FID_CACHE;

GTypeInfo_FID_CACHE GTypeInfoFc;

void cacheGTypeInfoFields(JNIEnv *env, jobject lpObject)
{
	if (GTypeInfoFc.cached) return;
	GTypeInfoFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GTypeInfoFc.value_table = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "value_table", "J");
	GTypeInfoFc.instance_init = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "instance_init", "J");
	GTypeInfoFc.n_preallocs = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "n_preallocs", "S");
	GTypeInfoFc.instance_size = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "instance_size", "S");
	GTypeInfoFc.class_data = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "class_data", "J");
	GTypeInfoFc.class_finalize = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "class_finalize", "J");
	GTypeInfoFc.class_init = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "class_init", "J");
	GTypeInfoFc.base_finalize = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "base_finalize", "J");
	GTypeInfoFc.base_init = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "base_init", "J");
	GTypeInfoFc.class_size = (*env)->GetFieldID(env, GTypeInfoFc.clazz, "class_size", "S");
	GTypeInfoFc.cached = 1;
}

GTypeInfo *getGTypeInfoFields(JNIEnv *env, jobject lpObject, GTypeInfo *lpStruct)
{
	if (!GTypeInfoFc.cached) cacheGTypeInfoFields(env, lpObject);
	lpStruct->value_table = (GTypeValueTable *)(*env)->GetLongField(env, lpObject, GTypeInfoFc.value_table);
	lpStruct->instance_init = (GInstanceInitFunc)(*env)->GetLongField(env, lpObject, GTypeInfoFc.instance_init);
	lpStruct->n_preallocs = (guint16)(*env)->GetShortField(env, lpObject, GTypeInfoFc.n_preallocs);
	lpStruct->instance_size = (guint16)(*env)->GetShortField(env, lpObject, GTypeInfoFc.instance_size);
	lpStruct->class_data = (gconstpointer)(*env)->GetLongField(env, lpObject, GTypeInfoFc.class_data);
	lpStruct->class_finalize = (GClassFinalizeFunc)(*env)->GetLongField(env, lpObject, GTypeInfoFc.class_finalize);
	lpStruct->class_init = (GClassInitFunc)(*env)->GetLongField(env, lpObject, GTypeInfoFc.class_init);
	lpStruct->base_finalize = (GBaseFinalizeFunc)(*env)->GetLongField(env, lpObject, GTypeInfoFc.base_finalize);
	lpStruct->base_init = (GBaseInitFunc)(*env)->GetLongField(env, lpObject, GTypeInfoFc.base_init);
	lpStruct->class_size = (guint16)(*env)->GetShortField(env, lpObject, GTypeInfoFc.class_size);
	return lpStruct;
}

void setGTypeInfoFields(JNIEnv *env, jobject lpObject, GTypeInfo *lpStruct)
{
	if (!GTypeInfoFc.cached) cacheGTypeInfoFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.value_table, (jlong)lpStruct->value_table);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.instance_init, (jlong)lpStruct->instance_init);
	(*env)->SetShortField(env, lpObject, GTypeInfoFc.n_preallocs, (jshort)lpStruct->n_preallocs);
	(*env)->SetShortField(env, lpObject, GTypeInfoFc.instance_size, (jshort)lpStruct->instance_size);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.class_data, (jlong)lpStruct->class_data);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.class_finalize, (jlong)lpStruct->class_finalize);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.class_init, (jlong)lpStruct->class_init);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.base_finalize, (jlong)lpStruct->base_finalize);
	(*env)->SetLongField(env, lpObject, GTypeInfoFc.base_init, (jlong)lpStruct->base_init);
	(*env)->SetShortField(env, lpObject, GTypeInfoFc.class_size, (jshort)lpStruct->class_size);
}
#endif

#ifndef NO_GTypeQuery
typedef struct GTypeQuery_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID instance_size, class_size, type_name, type;
} GTypeQuery_FID_CACHE;

GTypeQuery_FID_CACHE GTypeQueryFc;

void cacheGTypeQueryFields(JNIEnv *env, jobject lpObject)
{
	if (GTypeQueryFc.cached) return;
	GTypeQueryFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GTypeQueryFc.instance_size = (*env)->GetFieldID(env, GTypeQueryFc.clazz, "instance_size", "I");
	GTypeQueryFc.class_size = (*env)->GetFieldID(env, GTypeQueryFc.clazz, "class_size", "I");
	GTypeQueryFc.type_name = (*env)->GetFieldID(env, GTypeQueryFc.clazz, "type_name", "J");
	GTypeQueryFc.type = (*env)->GetFieldID(env, GTypeQueryFc.clazz, "type", "I");
	GTypeQueryFc.cached = 1;
}

GTypeQuery *getGTypeQueryFields(JNIEnv *env, jobject lpObject, GTypeQuery *lpStruct)
{
	if (!GTypeQueryFc.cached) cacheGTypeQueryFields(env, lpObject);
	lpStruct->instance_size = (guint)(*env)->GetIntField(env, lpObject, GTypeQueryFc.instance_size);
	lpStruct->class_size = (guint)(*env)->GetIntField(env, lpObject, GTypeQueryFc.class_size);
	lpStruct->type_name = (const gchar *)(*env)->GetLongField(env, lpObject, GTypeQueryFc.type_name);
	lpStruct->type = (GType)(*env)->GetIntField(env, lpObject, GTypeQueryFc.type);
	return lpStruct;
}

void setGTypeQueryFields(JNIEnv *env, jobject lpObject, GTypeQuery *lpStruct)
{
	if (!GTypeQueryFc.cached) cacheGTypeQueryFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GTypeQueryFc.instance_size, (jint)lpStruct->instance_size);
	(*env)->SetIntField(env, lpObject, GTypeQueryFc.class_size, (jint)lpStruct->class_size);
	(*env)->SetLongField(env, lpObject, GTypeQueryFc.type_name, (jlong)lpStruct->type_name);
	(*env)->SetIntField(env, lpObject, GTypeQueryFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_GdkColor
typedef struct GdkColor_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID blue, green, red, pixel;
} GdkColor_FID_CACHE;

GdkColor_FID_CACHE GdkColorFc;

void cacheGdkColorFields(JNIEnv *env, jobject lpObject)
{
	if (GdkColorFc.cached) return;
	GdkColorFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkColorFc.blue = (*env)->GetFieldID(env, GdkColorFc.clazz, "blue", "S");
	GdkColorFc.green = (*env)->GetFieldID(env, GdkColorFc.clazz, "green", "S");
	GdkColorFc.red = (*env)->GetFieldID(env, GdkColorFc.clazz, "red", "S");
	GdkColorFc.pixel = (*env)->GetFieldID(env, GdkColorFc.clazz, "pixel", "I");
	GdkColorFc.cached = 1;
}

GdkColor *getGdkColorFields(JNIEnv *env, jobject lpObject, GdkColor *lpStruct)
{
	if (!GdkColorFc.cached) cacheGdkColorFields(env, lpObject);
	lpStruct->blue = (guint16)(*env)->GetShortField(env, lpObject, GdkColorFc.blue);
	lpStruct->green = (guint16)(*env)->GetShortField(env, lpObject, GdkColorFc.green);
	lpStruct->red = (guint16)(*env)->GetShortField(env, lpObject, GdkColorFc.red);
	lpStruct->pixel = (guint32)(*env)->GetIntField(env, lpObject, GdkColorFc.pixel);
	return lpStruct;
}

void setGdkColorFields(JNIEnv *env, jobject lpObject, GdkColor *lpStruct)
{
	if (!GdkColorFc.cached) cacheGdkColorFields(env, lpObject);
	(*env)->SetShortField(env, lpObject, GdkColorFc.blue, (jshort)lpStruct->blue);
	(*env)->SetShortField(env, lpObject, GdkColorFc.green, (jshort)lpStruct->green);
	(*env)->SetShortField(env, lpObject, GdkColorFc.red, (jshort)lpStruct->red);
	(*env)->SetIntField(env, lpObject, GdkColorFc.pixel, (jint)lpStruct->pixel);
}
#endif

#ifndef NO_GdkDragContext
typedef struct GdkDragContext_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID start_time, action, suggested_action, actions, targets, dest_window, source_window, is_source, protocol;
} GdkDragContext_FID_CACHE;

GdkDragContext_FID_CACHE GdkDragContextFc;

void cacheGdkDragContextFields(JNIEnv *env, jobject lpObject)
{
	if (GdkDragContextFc.cached) return;
	GdkDragContextFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkDragContextFc.start_time = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "start_time", "I");
	GdkDragContextFc.action = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "action", "I");
	GdkDragContextFc.suggested_action = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "suggested_action", "I");
	GdkDragContextFc.actions = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "actions", "I");
	GdkDragContextFc.targets = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "targets", "J");
	GdkDragContextFc.dest_window = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "dest_window", "J");
	GdkDragContextFc.source_window = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "source_window", "J");
	GdkDragContextFc.is_source = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "is_source", "Z");
	GdkDragContextFc.protocol = (*env)->GetFieldID(env, GdkDragContextFc.clazz, "protocol", "I");
	GdkDragContextFc.cached = 1;
}

GdkDragContext *getGdkDragContextFields(JNIEnv *env, jobject lpObject, GdkDragContext *lpStruct)
{
	if (!GdkDragContextFc.cached) cacheGdkDragContextFields(env, lpObject);
	lpStruct->start_time = (guint32)(*env)->GetIntField(env, lpObject, GdkDragContextFc.start_time);
	lpStruct->action = (GdkDragAction)(*env)->GetIntField(env, lpObject, GdkDragContextFc.action);
	lpStruct->suggested_action = (GdkDragAction)(*env)->GetIntField(env, lpObject, GdkDragContextFc.suggested_action);
	lpStruct->actions = (GdkDragAction)(*env)->GetIntField(env, lpObject, GdkDragContextFc.actions);
	lpStruct->targets = (GList *)(*env)->GetLongField(env, lpObject, GdkDragContextFc.targets);
	lpStruct->dest_window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkDragContextFc.dest_window);
	lpStruct->source_window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkDragContextFc.source_window);
	lpStruct->is_source = (gboolean)(*env)->GetBooleanField(env, lpObject, GdkDragContextFc.is_source);
	lpStruct->protocol = (GdkDragProtocol)(*env)->GetIntField(env, lpObject, GdkDragContextFc.protocol);
	return lpStruct;
}

void setGdkDragContextFields(JNIEnv *env, jobject lpObject, GdkDragContext *lpStruct)
{
	if (!GdkDragContextFc.cached) cacheGdkDragContextFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkDragContextFc.start_time, (jint)lpStruct->start_time);
	(*env)->SetIntField(env, lpObject, GdkDragContextFc.action, (jint)lpStruct->action);
	(*env)->SetIntField(env, lpObject, GdkDragContextFc.suggested_action, (jint)lpStruct->suggested_action);
	(*env)->SetIntField(env, lpObject, GdkDragContextFc.actions, (jint)lpStruct->actions);
	(*env)->SetLongField(env, lpObject, GdkDragContextFc.targets, (jlong)lpStruct->targets);
	(*env)->SetLongField(env, lpObject, GdkDragContextFc.dest_window, (jlong)lpStruct->dest_window);
	(*env)->SetLongField(env, lpObject, GdkDragContextFc.source_window, (jlong)lpStruct->source_window);
	(*env)->SetBooleanField(env, lpObject, GdkDragContextFc.is_source, (jboolean)lpStruct->is_source);
	(*env)->SetIntField(env, lpObject, GdkDragContextFc.protocol, (jint)lpStruct->protocol);
}
#endif

#ifndef NO_GdkEvent
typedef struct GdkEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID type;
} GdkEvent_FID_CACHE;

GdkEvent_FID_CACHE GdkEventFc;

void cacheGdkEventFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventFc.cached) return;
	GdkEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventFc.type = (*env)->GetFieldID(env, GdkEventFc.clazz, "type", "I");
	GdkEventFc.cached = 1;
}

GdkEvent *getGdkEventFields(JNIEnv *env, jobject lpObject, GdkEvent *lpStruct)
{
	if (!GdkEventFc.cached) cacheGdkEventFields(env, lpObject);
	lpStruct->type = (GdkEventType)(*env)->GetIntField(env, lpObject, GdkEventFc.type);
	return lpStruct;
}

void setGdkEventFields(JNIEnv *env, jobject lpObject, GdkEvent *lpStruct)
{
	if (!GdkEventFc.cached) cacheGdkEventFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkEventFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_GdkEventAny
typedef struct GdkEventAny_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID send_event, window;
} GdkEventAny_FID_CACHE;

GdkEventAny_FID_CACHE GdkEventAnyFc;

void cacheGdkEventAnyFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventAnyFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventAnyFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventAnyFc.send_event = (*env)->GetFieldID(env, GdkEventAnyFc.clazz, "send_event", "B");
	GdkEventAnyFc.window = (*env)->GetFieldID(env, GdkEventAnyFc.clazz, "window", "J");
	GdkEventAnyFc.cached = 1;
}

GdkEventAny *getGdkEventAnyFields(JNIEnv *env, jobject lpObject, GdkEventAny *lpStruct)
{
	if (!GdkEventAnyFc.cached) cacheGdkEventAnyFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventAnyFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventAnyFc.window);
	return lpStruct;
}

void setGdkEventAnyFields(JNIEnv *env, jobject lpObject, GdkEventAny *lpStruct)
{
	if (!GdkEventAnyFc.cached) cacheGdkEventAnyFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetByteField(env, lpObject, GdkEventAnyFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventAnyFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventButton
typedef struct GdkEventButton_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID y_root, x_root, device, button, state, axes, y, x, time, send_event, window;
} GdkEventButton_FID_CACHE;

GdkEventButton_FID_CACHE GdkEventButtonFc;

void cacheGdkEventButtonFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventButtonFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventButtonFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventButtonFc.y_root = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "y_root", "D");
	GdkEventButtonFc.x_root = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "x_root", "D");
	GdkEventButtonFc.device = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "device", "J");
	GdkEventButtonFc.button = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "button", "I");
	GdkEventButtonFc.state = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "state", "I");
	GdkEventButtonFc.axes = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "axes", "J");
	GdkEventButtonFc.y = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "y", "D");
	GdkEventButtonFc.x = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "x", "D");
	GdkEventButtonFc.time = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "time", "I");
	GdkEventButtonFc.send_event = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "send_event", "B");
	GdkEventButtonFc.window = (*env)->GetFieldID(env, GdkEventButtonFc.clazz, "window", "J");
	GdkEventButtonFc.cached = 1;
}

GdkEventButton *getGdkEventButtonFields(JNIEnv *env, jobject lpObject, GdkEventButton *lpStruct)
{
	if (!GdkEventButtonFc.cached) cacheGdkEventButtonFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->y_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventButtonFc.y_root);
	lpStruct->x_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventButtonFc.x_root);
	lpStruct->device = (GdkDevice *)(*env)->GetLongField(env, lpObject, GdkEventButtonFc.device);
	lpStruct->button = (guint)(*env)->GetIntField(env, lpObject, GdkEventButtonFc.button);
	lpStruct->state = (guint)(*env)->GetIntField(env, lpObject, GdkEventButtonFc.state);
	lpStruct->axes = (gdouble *)(*env)->GetLongField(env, lpObject, GdkEventButtonFc.axes);
	lpStruct->y = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventButtonFc.y);
	lpStruct->x = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventButtonFc.x);
	lpStruct->time = (guint32)(*env)->GetIntField(env, lpObject, GdkEventButtonFc.time);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventButtonFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventButtonFc.window);
	return lpStruct;
}

void setGdkEventButtonFields(JNIEnv *env, jobject lpObject, GdkEventButton *lpStruct)
{
	if (!GdkEventButtonFc.cached) cacheGdkEventButtonFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetDoubleField(env, lpObject, GdkEventButtonFc.y_root, (jdouble)lpStruct->y_root);
	(*env)->SetDoubleField(env, lpObject, GdkEventButtonFc.x_root, (jdouble)lpStruct->x_root);
	(*env)->SetLongField(env, lpObject, GdkEventButtonFc.device, (jlong)lpStruct->device);
	(*env)->SetIntField(env, lpObject, GdkEventButtonFc.button, (jint)lpStruct->button);
	(*env)->SetIntField(env, lpObject, GdkEventButtonFc.state, (jint)lpStruct->state);
	(*env)->SetLongField(env, lpObject, GdkEventButtonFc.axes, (jlong)lpStruct->axes);
	(*env)->SetDoubleField(env, lpObject, GdkEventButtonFc.y, (jdouble)lpStruct->y);
	(*env)->SetDoubleField(env, lpObject, GdkEventButtonFc.x, (jdouble)lpStruct->x);
	(*env)->SetIntField(env, lpObject, GdkEventButtonFc.time, (jint)lpStruct->time);
	(*env)->SetByteField(env, lpObject, GdkEventButtonFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventButtonFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventCrossing
typedef struct GdkEventCrossing_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID state, focus, detail, mode, y_root, x_root, y, x, time, subwindow, send_event, window;
} GdkEventCrossing_FID_CACHE;

GdkEventCrossing_FID_CACHE GdkEventCrossingFc;

void cacheGdkEventCrossingFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventCrossingFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventCrossingFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventCrossingFc.state = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "state", "I");
	GdkEventCrossingFc.focus = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "focus", "Z");
	GdkEventCrossingFc.detail = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "detail", "I");
	GdkEventCrossingFc.mode = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "mode", "I");
	GdkEventCrossingFc.y_root = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "y_root", "D");
	GdkEventCrossingFc.x_root = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "x_root", "D");
	GdkEventCrossingFc.y = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "y", "D");
	GdkEventCrossingFc.x = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "x", "D");
	GdkEventCrossingFc.time = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "time", "I");
	GdkEventCrossingFc.subwindow = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "subwindow", "J");
	GdkEventCrossingFc.send_event = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "send_event", "B");
	GdkEventCrossingFc.window = (*env)->GetFieldID(env, GdkEventCrossingFc.clazz, "window", "J");
	GdkEventCrossingFc.cached = 1;
}

GdkEventCrossing *getGdkEventCrossingFields(JNIEnv *env, jobject lpObject, GdkEventCrossing *lpStruct)
{
	if (!GdkEventCrossingFc.cached) cacheGdkEventCrossingFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->state = (*env)->GetIntField(env, lpObject, GdkEventCrossingFc.state);
	lpStruct->focus = (gboolean)(*env)->GetBooleanField(env, lpObject, GdkEventCrossingFc.focus);
	lpStruct->detail = (GdkNotifyType)(*env)->GetIntField(env, lpObject, GdkEventCrossingFc.detail);
	lpStruct->mode = (GdkCrossingMode)(*env)->GetIntField(env, lpObject, GdkEventCrossingFc.mode);
	lpStruct->y_root = (*env)->GetDoubleField(env, lpObject, GdkEventCrossingFc.y_root);
	lpStruct->x_root = (*env)->GetDoubleField(env, lpObject, GdkEventCrossingFc.x_root);
	lpStruct->y = (*env)->GetDoubleField(env, lpObject, GdkEventCrossingFc.y);
	lpStruct->x = (*env)->GetDoubleField(env, lpObject, GdkEventCrossingFc.x);
	lpStruct->time = (*env)->GetIntField(env, lpObject, GdkEventCrossingFc.time);
	lpStruct->subwindow = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventCrossingFc.subwindow);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventCrossingFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventCrossingFc.window);
	return lpStruct;
}

void setGdkEventCrossingFields(JNIEnv *env, jobject lpObject, GdkEventCrossing *lpStruct)
{
	if (!GdkEventCrossingFc.cached) cacheGdkEventCrossingFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, GdkEventCrossingFc.state, (jint)lpStruct->state);
	(*env)->SetBooleanField(env, lpObject, GdkEventCrossingFc.focus, (jboolean)lpStruct->focus);
	(*env)->SetIntField(env, lpObject, GdkEventCrossingFc.detail, (jint)lpStruct->detail);
	(*env)->SetIntField(env, lpObject, GdkEventCrossingFc.mode, (jint)lpStruct->mode);
	(*env)->SetDoubleField(env, lpObject, GdkEventCrossingFc.y_root, (jdouble)lpStruct->y_root);
	(*env)->SetDoubleField(env, lpObject, GdkEventCrossingFc.x_root, (jdouble)lpStruct->x_root);
	(*env)->SetDoubleField(env, lpObject, GdkEventCrossingFc.y, (jdouble)lpStruct->y);
	(*env)->SetDoubleField(env, lpObject, GdkEventCrossingFc.x, (jdouble)lpStruct->x);
	(*env)->SetIntField(env, lpObject, GdkEventCrossingFc.time, (jint)lpStruct->time);
	(*env)->SetLongField(env, lpObject, GdkEventCrossingFc.subwindow, (jlong)lpStruct->subwindow);
	(*env)->SetByteField(env, lpObject, GdkEventCrossingFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventCrossingFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventExpose
typedef struct GdkEventExpose_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID count, region, area_height, area_width, area_y, area_x, send_event, window;
} GdkEventExpose_FID_CACHE;

GdkEventExpose_FID_CACHE GdkEventExposeFc;

void cacheGdkEventExposeFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventExposeFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventExposeFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventExposeFc.count = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "count", "I");
	GdkEventExposeFc.region = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "region", "J");
	GdkEventExposeFc.area_height = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "area_height", "I");
	GdkEventExposeFc.area_width = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "area_width", "I");
	GdkEventExposeFc.area_y = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "area_y", "I");
	GdkEventExposeFc.area_x = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "area_x", "I");
	GdkEventExposeFc.send_event = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "send_event", "B");
	GdkEventExposeFc.window = (*env)->GetFieldID(env, GdkEventExposeFc.clazz, "window", "J");
	GdkEventExposeFc.cached = 1;
}

GdkEventExpose *getGdkEventExposeFields(JNIEnv *env, jobject lpObject, GdkEventExpose *lpStruct)
{
	if (!GdkEventExposeFc.cached) cacheGdkEventExposeFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->count = (gint)(*env)->GetIntField(env, lpObject, GdkEventExposeFc.count);
	lpStruct->region = (GdkRegion *)(*env)->GetLongField(env, lpObject, GdkEventExposeFc.region);
	lpStruct->area.height = (*env)->GetIntField(env, lpObject, GdkEventExposeFc.area_height);
	lpStruct->area.width = (*env)->GetIntField(env, lpObject, GdkEventExposeFc.area_width);
	lpStruct->area.y = (*env)->GetIntField(env, lpObject, GdkEventExposeFc.area_y);
	lpStruct->area.x = (*env)->GetIntField(env, lpObject, GdkEventExposeFc.area_x);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventExposeFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventExposeFc.window);
	return lpStruct;
}

void setGdkEventExposeFields(JNIEnv *env, jobject lpObject, GdkEventExpose *lpStruct)
{
	if (!GdkEventExposeFc.cached) cacheGdkEventExposeFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, GdkEventExposeFc.count, (jint)lpStruct->count);
	(*env)->SetLongField(env, lpObject, GdkEventExposeFc.region, (jlong)lpStruct->region);
	(*env)->SetIntField(env, lpObject, GdkEventExposeFc.area_height, (jint)lpStruct->area.height);
	(*env)->SetIntField(env, lpObject, GdkEventExposeFc.area_width, (jint)lpStruct->area.width);
	(*env)->SetIntField(env, lpObject, GdkEventExposeFc.area_y, (jint)lpStruct->area.y);
	(*env)->SetIntField(env, lpObject, GdkEventExposeFc.area_x, (jint)lpStruct->area.x);
	(*env)->SetByteField(env, lpObject, GdkEventExposeFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventExposeFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventFocus
typedef struct GdkEventFocus_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID in, send_event, window;
} GdkEventFocus_FID_CACHE;

GdkEventFocus_FID_CACHE GdkEventFocusFc;

void cacheGdkEventFocusFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventFocusFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventFocusFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventFocusFc.in = (*env)->GetFieldID(env, GdkEventFocusFc.clazz, "in", "S");
	GdkEventFocusFc.send_event = (*env)->GetFieldID(env, GdkEventFocusFc.clazz, "send_event", "B");
	GdkEventFocusFc.window = (*env)->GetFieldID(env, GdkEventFocusFc.clazz, "window", "J");
	GdkEventFocusFc.cached = 1;
}

GdkEventFocus *getGdkEventFocusFields(JNIEnv *env, jobject lpObject, GdkEventFocus *lpStruct)
{
	if (!GdkEventFocusFc.cached) cacheGdkEventFocusFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->in = (gint16)(*env)->GetShortField(env, lpObject, GdkEventFocusFc.in);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventFocusFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventFocusFc.window);
	return lpStruct;
}

void setGdkEventFocusFields(JNIEnv *env, jobject lpObject, GdkEventFocus *lpStruct)
{
	if (!GdkEventFocusFc.cached) cacheGdkEventFocusFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetShortField(env, lpObject, GdkEventFocusFc.in, (jshort)lpStruct->in);
	(*env)->SetByteField(env, lpObject, GdkEventFocusFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventFocusFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventKey
typedef struct GdkEventKey_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID group, hardware_keycode, string, length, keyval, state, time, send_event, window;
} GdkEventKey_FID_CACHE;

GdkEventKey_FID_CACHE GdkEventKeyFc;

void cacheGdkEventKeyFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventKeyFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventKeyFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventKeyFc.group = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "group", "B");
	GdkEventKeyFc.hardware_keycode = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "hardware_keycode", "S");
	GdkEventKeyFc.string = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "string", "J");
	GdkEventKeyFc.length = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "length", "I");
	GdkEventKeyFc.keyval = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "keyval", "I");
	GdkEventKeyFc.state = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "state", "I");
	GdkEventKeyFc.time = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "time", "I");
	GdkEventKeyFc.send_event = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "send_event", "B");
	GdkEventKeyFc.window = (*env)->GetFieldID(env, GdkEventKeyFc.clazz, "window", "J");
	GdkEventKeyFc.cached = 1;
}

GdkEventKey *getGdkEventKeyFields(JNIEnv *env, jobject lpObject, GdkEventKey *lpStruct)
{
	if (!GdkEventKeyFc.cached) cacheGdkEventKeyFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->group = (guint8)(*env)->GetByteField(env, lpObject, GdkEventKeyFc.group);
	lpStruct->hardware_keycode = (guint16)(*env)->GetShortField(env, lpObject, GdkEventKeyFc.hardware_keycode);
	lpStruct->string = (gchar *)(*env)->GetLongField(env, lpObject, GdkEventKeyFc.string);
	lpStruct->length = (gint)(*env)->GetIntField(env, lpObject, GdkEventKeyFc.length);
	lpStruct->keyval = (guint)(*env)->GetIntField(env, lpObject, GdkEventKeyFc.keyval);
	lpStruct->state = (guint)(*env)->GetIntField(env, lpObject, GdkEventKeyFc.state);
	lpStruct->time = (guint32)(*env)->GetIntField(env, lpObject, GdkEventKeyFc.time);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventKeyFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventKeyFc.window);
	return lpStruct;
}

void setGdkEventKeyFields(JNIEnv *env, jobject lpObject, GdkEventKey *lpStruct)
{
	if (!GdkEventKeyFc.cached) cacheGdkEventKeyFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetByteField(env, lpObject, GdkEventKeyFc.group, (jbyte)lpStruct->group);
	(*env)->SetShortField(env, lpObject, GdkEventKeyFc.hardware_keycode, (jshort)lpStruct->hardware_keycode);
	(*env)->SetLongField(env, lpObject, GdkEventKeyFc.string, (jlong)lpStruct->string);
	(*env)->SetIntField(env, lpObject, GdkEventKeyFc.length, (jint)lpStruct->length);
	(*env)->SetIntField(env, lpObject, GdkEventKeyFc.keyval, (jint)lpStruct->keyval);
	(*env)->SetIntField(env, lpObject, GdkEventKeyFc.state, (jint)lpStruct->state);
	(*env)->SetIntField(env, lpObject, GdkEventKeyFc.time, (jint)lpStruct->time);
	(*env)->SetByteField(env, lpObject, GdkEventKeyFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventKeyFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventMotion
typedef struct GdkEventMotion_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID y_root, x_root, device, is_hint, state, axes, y, x, time, send_event, window;
} GdkEventMotion_FID_CACHE;

GdkEventMotion_FID_CACHE GdkEventMotionFc;

void cacheGdkEventMotionFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventMotionFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventMotionFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventMotionFc.y_root = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "y_root", "D");
	GdkEventMotionFc.x_root = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "x_root", "D");
	GdkEventMotionFc.device = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "device", "J");
	GdkEventMotionFc.is_hint = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "is_hint", "S");
	GdkEventMotionFc.state = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "state", "I");
	GdkEventMotionFc.axes = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "axes", "J");
	GdkEventMotionFc.y = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "y", "D");
	GdkEventMotionFc.x = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "x", "D");
	GdkEventMotionFc.time = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "time", "I");
	GdkEventMotionFc.send_event = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "send_event", "B");
	GdkEventMotionFc.window = (*env)->GetFieldID(env, GdkEventMotionFc.clazz, "window", "J");
	GdkEventMotionFc.cached = 1;
}

GdkEventMotion *getGdkEventMotionFields(JNIEnv *env, jobject lpObject, GdkEventMotion *lpStruct)
{
	if (!GdkEventMotionFc.cached) cacheGdkEventMotionFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->y_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventMotionFc.y_root);
	lpStruct->x_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventMotionFc.x_root);
	lpStruct->device = (GdkDevice *)(*env)->GetLongField(env, lpObject, GdkEventMotionFc.device);
	lpStruct->is_hint = (gint16)(*env)->GetShortField(env, lpObject, GdkEventMotionFc.is_hint);
	lpStruct->state = (guint)(*env)->GetIntField(env, lpObject, GdkEventMotionFc.state);
	lpStruct->axes = (gdouble *)(*env)->GetLongField(env, lpObject, GdkEventMotionFc.axes);
	lpStruct->y = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventMotionFc.y);
	lpStruct->x = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventMotionFc.x);
	lpStruct->time = (guint32)(*env)->GetIntField(env, lpObject, GdkEventMotionFc.time);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventMotionFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventMotionFc.window);
	return lpStruct;
}

void setGdkEventMotionFields(JNIEnv *env, jobject lpObject, GdkEventMotion *lpStruct)
{
	if (!GdkEventMotionFc.cached) cacheGdkEventMotionFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetDoubleField(env, lpObject, GdkEventMotionFc.y_root, (jdouble)lpStruct->y_root);
	(*env)->SetDoubleField(env, lpObject, GdkEventMotionFc.x_root, (jdouble)lpStruct->x_root);
	(*env)->SetLongField(env, lpObject, GdkEventMotionFc.device, (jlong)lpStruct->device);
	(*env)->SetShortField(env, lpObject, GdkEventMotionFc.is_hint, (jshort)lpStruct->is_hint);
	(*env)->SetIntField(env, lpObject, GdkEventMotionFc.state, (jint)lpStruct->state);
	(*env)->SetLongField(env, lpObject, GdkEventMotionFc.axes, (jlong)lpStruct->axes);
	(*env)->SetDoubleField(env, lpObject, GdkEventMotionFc.y, (jdouble)lpStruct->y);
	(*env)->SetDoubleField(env, lpObject, GdkEventMotionFc.x, (jdouble)lpStruct->x);
	(*env)->SetIntField(env, lpObject, GdkEventMotionFc.time, (jint)lpStruct->time);
	(*env)->SetByteField(env, lpObject, GdkEventMotionFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventMotionFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventScroll
typedef struct GdkEventScroll_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID y_root, x_root, device, direction, state, y, x, time, send_event, window;
} GdkEventScroll_FID_CACHE;

GdkEventScroll_FID_CACHE GdkEventScrollFc;

void cacheGdkEventScrollFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventScrollFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventScrollFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventScrollFc.y_root = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "y_root", "D");
	GdkEventScrollFc.x_root = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "x_root", "D");
	GdkEventScrollFc.device = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "device", "J");
	GdkEventScrollFc.direction = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "direction", "I");
	GdkEventScrollFc.state = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "state", "I");
	GdkEventScrollFc.y = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "y", "D");
	GdkEventScrollFc.x = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "x", "D");
	GdkEventScrollFc.time = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "time", "I");
	GdkEventScrollFc.send_event = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "send_event", "B");
	GdkEventScrollFc.window = (*env)->GetFieldID(env, GdkEventScrollFc.clazz, "window", "J");
	GdkEventScrollFc.cached = 1;
}

GdkEventScroll *getGdkEventScrollFields(JNIEnv *env, jobject lpObject, GdkEventScroll *lpStruct)
{
	if (!GdkEventScrollFc.cached) cacheGdkEventScrollFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->y_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventScrollFc.y_root);
	lpStruct->x_root = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventScrollFc.x_root);
	lpStruct->device = (GdkDevice *)(*env)->GetLongField(env, lpObject, GdkEventScrollFc.device);
	lpStruct->direction = (GdkScrollDirection)(*env)->GetIntField(env, lpObject, GdkEventScrollFc.direction);
	lpStruct->state = (guint)(*env)->GetIntField(env, lpObject, GdkEventScrollFc.state);
	lpStruct->y = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventScrollFc.y);
	lpStruct->x = (gdouble)(*env)->GetDoubleField(env, lpObject, GdkEventScrollFc.x);
	lpStruct->time = (guint32)(*env)->GetIntField(env, lpObject, GdkEventScrollFc.time);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventScrollFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventScrollFc.window);
	return lpStruct;
}

void setGdkEventScrollFields(JNIEnv *env, jobject lpObject, GdkEventScroll *lpStruct)
{
	if (!GdkEventScrollFc.cached) cacheGdkEventScrollFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetDoubleField(env, lpObject, GdkEventScrollFc.y_root, (jdouble)lpStruct->y_root);
	(*env)->SetDoubleField(env, lpObject, GdkEventScrollFc.x_root, (jdouble)lpStruct->x_root);
	(*env)->SetLongField(env, lpObject, GdkEventScrollFc.device, (jlong)lpStruct->device);
	(*env)->SetIntField(env, lpObject, GdkEventScrollFc.direction, (jint)lpStruct->direction);
	(*env)->SetIntField(env, lpObject, GdkEventScrollFc.state, (jint)lpStruct->state);
	(*env)->SetDoubleField(env, lpObject, GdkEventScrollFc.y, (jdouble)lpStruct->y);
	(*env)->SetDoubleField(env, lpObject, GdkEventScrollFc.x, (jdouble)lpStruct->x);
	(*env)->SetIntField(env, lpObject, GdkEventScrollFc.time, (jint)lpStruct->time);
	(*env)->SetByteField(env, lpObject, GdkEventScrollFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventScrollFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventVisibility
typedef struct GdkEventVisibility_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID state, send_event, window;
} GdkEventVisibility_FID_CACHE;

GdkEventVisibility_FID_CACHE GdkEventVisibilityFc;

void cacheGdkEventVisibilityFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventVisibilityFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventVisibilityFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventVisibilityFc.state = (*env)->GetFieldID(env, GdkEventVisibilityFc.clazz, "state", "I");
	GdkEventVisibilityFc.send_event = (*env)->GetFieldID(env, GdkEventVisibilityFc.clazz, "send_event", "B");
	GdkEventVisibilityFc.window = (*env)->GetFieldID(env, GdkEventVisibilityFc.clazz, "window", "J");
	GdkEventVisibilityFc.cached = 1;
}

GdkEventVisibility *getGdkEventVisibilityFields(JNIEnv *env, jobject lpObject, GdkEventVisibility *lpStruct)
{
	if (!GdkEventVisibilityFc.cached) cacheGdkEventVisibilityFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->state = (GdkVisibilityState)(*env)->GetIntField(env, lpObject, GdkEventVisibilityFc.state);
	lpStruct->send_event = (gint8)(*env)->GetByteField(env, lpObject, GdkEventVisibilityFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventVisibilityFc.window);
	return lpStruct;
}

void setGdkEventVisibilityFields(JNIEnv *env, jobject lpObject, GdkEventVisibility *lpStruct)
{
	if (!GdkEventVisibilityFc.cached) cacheGdkEventVisibilityFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, GdkEventVisibilityFc.state, (jint)lpStruct->state);
	(*env)->SetByteField(env, lpObject, GdkEventVisibilityFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventVisibilityFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkEventWindowState
typedef struct GdkEventWindowState_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID new_window_state, changed_mask, send_event, window;
} GdkEventWindowState_FID_CACHE;

GdkEventWindowState_FID_CACHE GdkEventWindowStateFc;

void cacheGdkEventWindowStateFields(JNIEnv *env, jobject lpObject)
{
	if (GdkEventWindowStateFc.cached) return;
	cacheGdkEventFields(env, lpObject);
	GdkEventWindowStateFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkEventWindowStateFc.new_window_state = (*env)->GetFieldID(env, GdkEventWindowStateFc.clazz, "new_window_state", "I");
	GdkEventWindowStateFc.changed_mask = (*env)->GetFieldID(env, GdkEventWindowStateFc.clazz, "changed_mask", "I");
	GdkEventWindowStateFc.send_event = (*env)->GetFieldID(env, GdkEventWindowStateFc.clazz, "send_event", "B");
	GdkEventWindowStateFc.window = (*env)->GetFieldID(env, GdkEventWindowStateFc.clazz, "window", "J");
	GdkEventWindowStateFc.cached = 1;
}

GdkEventWindowState *getGdkEventWindowStateFields(JNIEnv *env, jobject lpObject, GdkEventWindowState *lpStruct)
{
	if (!GdkEventWindowStateFc.cached) cacheGdkEventWindowStateFields(env, lpObject);
	getGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	lpStruct->new_window_state = (*env)->GetIntField(env, lpObject, GdkEventWindowStateFc.new_window_state);
	lpStruct->changed_mask = (*env)->GetIntField(env, lpObject, GdkEventWindowStateFc.changed_mask);
	lpStruct->send_event = (*env)->GetByteField(env, lpObject, GdkEventWindowStateFc.send_event);
	lpStruct->window = (GdkWindow *)(*env)->GetLongField(env, lpObject, GdkEventWindowStateFc.window);
	return lpStruct;
}

void setGdkEventWindowStateFields(JNIEnv *env, jobject lpObject, GdkEventWindowState *lpStruct)
{
	if (!GdkEventWindowStateFc.cached) cacheGdkEventWindowStateFields(env, lpObject);
	setGdkEventFields(env, lpObject, (GdkEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, GdkEventWindowStateFc.new_window_state, (jint)lpStruct->new_window_state);
	(*env)->SetIntField(env, lpObject, GdkEventWindowStateFc.changed_mask, (jint)lpStruct->changed_mask);
	(*env)->SetByteField(env, lpObject, GdkEventWindowStateFc.send_event, (jbyte)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, GdkEventWindowStateFc.window, (jlong)lpStruct->window);
}
#endif

#ifndef NO_GdkGCValues
typedef struct GdkGCValues_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID join_style, cap_style, line_style, line_width, graphics_exposures, clip_y_origin, clip_x_origin, ts_y_origin, ts_x_origin, subwindow_mode, clip_mask, stipple, tile, fill, function, font, background_blue, background_green, background_red, background_pixel, foreground_blue, foreground_green, foreground_red, foreground_pixel;
} GdkGCValues_FID_CACHE;

GdkGCValues_FID_CACHE GdkGCValuesFc;

void cacheGdkGCValuesFields(JNIEnv *env, jobject lpObject)
{
	if (GdkGCValuesFc.cached) return;
	GdkGCValuesFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkGCValuesFc.join_style = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "join_style", "I");
	GdkGCValuesFc.cap_style = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "cap_style", "I");
	GdkGCValuesFc.line_style = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "line_style", "I");
	GdkGCValuesFc.line_width = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "line_width", "I");
	GdkGCValuesFc.graphics_exposures = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "graphics_exposures", "I");
	GdkGCValuesFc.clip_y_origin = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "clip_y_origin", "I");
	GdkGCValuesFc.clip_x_origin = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "clip_x_origin", "I");
	GdkGCValuesFc.ts_y_origin = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "ts_y_origin", "I");
	GdkGCValuesFc.ts_x_origin = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "ts_x_origin", "I");
	GdkGCValuesFc.subwindow_mode = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "subwindow_mode", "I");
	GdkGCValuesFc.clip_mask = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "clip_mask", "J");
	GdkGCValuesFc.stipple = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "stipple", "J");
	GdkGCValuesFc.tile = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "tile", "J");
	GdkGCValuesFc.fill = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "fill", "I");
	GdkGCValuesFc.function = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "function", "J");
	GdkGCValuesFc.font = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "font", "J");
	GdkGCValuesFc.background_blue = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "background_blue", "S");
	GdkGCValuesFc.background_green = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "background_green", "S");
	GdkGCValuesFc.background_red = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "background_red", "S");
	GdkGCValuesFc.background_pixel = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "background_pixel", "I");
	GdkGCValuesFc.foreground_blue = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "foreground_blue", "S");
	GdkGCValuesFc.foreground_green = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "foreground_green", "S");
	GdkGCValuesFc.foreground_red = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "foreground_red", "S");
	GdkGCValuesFc.foreground_pixel = (*env)->GetFieldID(env, GdkGCValuesFc.clazz, "foreground_pixel", "I");
	GdkGCValuesFc.cached = 1;
}

GdkGCValues *getGdkGCValuesFields(JNIEnv *env, jobject lpObject, GdkGCValues *lpStruct)
{
	if (!GdkGCValuesFc.cached) cacheGdkGCValuesFields(env, lpObject);
	lpStruct->join_style = (GdkJoinStyle)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.join_style);
	lpStruct->cap_style = (GdkCapStyle)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.cap_style);
	lpStruct->line_style = (GdkLineStyle)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.line_style);
	lpStruct->line_width = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.line_width);
	lpStruct->graphics_exposures = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.graphics_exposures);
	lpStruct->clip_y_origin = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.clip_y_origin);
	lpStruct->clip_x_origin = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.clip_x_origin);
	lpStruct->ts_y_origin = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.ts_y_origin);
	lpStruct->ts_x_origin = (gint)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.ts_x_origin);
	lpStruct->subwindow_mode = (GdkSubwindowMode)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.subwindow_mode);
	lpStruct->clip_mask = (GdkPixmap *)(*env)->GetLongField(env, lpObject, GdkGCValuesFc.clip_mask);
	lpStruct->stipple = (GdkPixmap *)(*env)->GetLongField(env, lpObject, GdkGCValuesFc.stipple);
	lpStruct->tile = (GdkPixmap *)(*env)->GetLongField(env, lpObject, GdkGCValuesFc.tile);
	lpStruct->fill = (GdkFill)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.fill);
	lpStruct->function = (GdkFunction)(*env)->GetLongField(env, lpObject, GdkGCValuesFc.function);
	lpStruct->font = (GdkFont *)(*env)->GetLongField(env, lpObject, GdkGCValuesFc.font);
	lpStruct->background.blue = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.background_blue);
	lpStruct->background.green = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.background_green);
	lpStruct->background.red = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.background_red);
	lpStruct->background.pixel = (guint32)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.background_pixel);
	lpStruct->foreground.blue = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.foreground_blue);
	lpStruct->foreground.green = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.foreground_green);
	lpStruct->foreground.red = (guint16)(*env)->GetShortField(env, lpObject, GdkGCValuesFc.foreground_red);
	lpStruct->foreground.pixel = (guint32)(*env)->GetIntField(env, lpObject, GdkGCValuesFc.foreground_pixel);
	return lpStruct;
}

void setGdkGCValuesFields(JNIEnv *env, jobject lpObject, GdkGCValues *lpStruct)
{
	if (!GdkGCValuesFc.cached) cacheGdkGCValuesFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.join_style, (jint)lpStruct->join_style);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.cap_style, (jint)lpStruct->cap_style);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.line_style, (jint)lpStruct->line_style);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.line_width, (jint)lpStruct->line_width);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.graphics_exposures, (jint)lpStruct->graphics_exposures);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.clip_y_origin, (jint)lpStruct->clip_y_origin);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.clip_x_origin, (jint)lpStruct->clip_x_origin);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.ts_y_origin, (jint)lpStruct->ts_y_origin);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.ts_x_origin, (jint)lpStruct->ts_x_origin);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.subwindow_mode, (jint)lpStruct->subwindow_mode);
	(*env)->SetLongField(env, lpObject, GdkGCValuesFc.clip_mask, (jlong)lpStruct->clip_mask);
	(*env)->SetLongField(env, lpObject, GdkGCValuesFc.stipple, (jlong)lpStruct->stipple);
	(*env)->SetLongField(env, lpObject, GdkGCValuesFc.tile, (jlong)lpStruct->tile);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.fill, (jint)lpStruct->fill);
	(*env)->SetLongField(env, lpObject, GdkGCValuesFc.function, (jlong)lpStruct->function);
	(*env)->SetLongField(env, lpObject, GdkGCValuesFc.font, (jlong)lpStruct->font);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.background_blue, (jshort)lpStruct->background.blue);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.background_green, (jshort)lpStruct->background.green);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.background_red, (jshort)lpStruct->background.red);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.background_pixel, (jint)lpStruct->background.pixel);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.foreground_blue, (jshort)lpStruct->foreground.blue);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.foreground_green, (jshort)lpStruct->foreground.green);
	(*env)->SetShortField(env, lpObject, GdkGCValuesFc.foreground_red, (jshort)lpStruct->foreground.red);
	(*env)->SetIntField(env, lpObject, GdkGCValuesFc.foreground_pixel, (jint)lpStruct->foreground.pixel);
}
#endif

#ifndef NO_GdkGeometry
typedef struct GdkGeometry_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID win_gravity, max_aspect, min_aspect, height_inc, width_inc, base_height, base_width, max_height, max_width, min_height, min_width;
} GdkGeometry_FID_CACHE;

GdkGeometry_FID_CACHE GdkGeometryFc;

void cacheGdkGeometryFields(JNIEnv *env, jobject lpObject)
{
	if (GdkGeometryFc.cached) return;
	GdkGeometryFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkGeometryFc.win_gravity = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "win_gravity", "I");
	GdkGeometryFc.max_aspect = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "max_aspect", "D");
	GdkGeometryFc.min_aspect = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "min_aspect", "D");
	GdkGeometryFc.height_inc = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "height_inc", "I");
	GdkGeometryFc.width_inc = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "width_inc", "I");
	GdkGeometryFc.base_height = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "base_height", "I");
	GdkGeometryFc.base_width = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "base_width", "I");
	GdkGeometryFc.max_height = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "max_height", "I");
	GdkGeometryFc.max_width = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "max_width", "I");
	GdkGeometryFc.min_height = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "min_height", "I");
	GdkGeometryFc.min_width = (*env)->GetFieldID(env, GdkGeometryFc.clazz, "min_width", "I");
	GdkGeometryFc.cached = 1;
}

GdkGeometry *getGdkGeometryFields(JNIEnv *env, jobject lpObject, GdkGeometry *lpStruct)
{
	if (!GdkGeometryFc.cached) cacheGdkGeometryFields(env, lpObject);
	lpStruct->win_gravity = (*env)->GetIntField(env, lpObject, GdkGeometryFc.win_gravity);
	lpStruct->max_aspect = (*env)->GetDoubleField(env, lpObject, GdkGeometryFc.max_aspect);
	lpStruct->min_aspect = (*env)->GetDoubleField(env, lpObject, GdkGeometryFc.min_aspect);
	lpStruct->height_inc = (*env)->GetIntField(env, lpObject, GdkGeometryFc.height_inc);
	lpStruct->width_inc = (*env)->GetIntField(env, lpObject, GdkGeometryFc.width_inc);
	lpStruct->base_height = (*env)->GetIntField(env, lpObject, GdkGeometryFc.base_height);
	lpStruct->base_width = (*env)->GetIntField(env, lpObject, GdkGeometryFc.base_width);
	lpStruct->max_height = (*env)->GetIntField(env, lpObject, GdkGeometryFc.max_height);
	lpStruct->max_width = (*env)->GetIntField(env, lpObject, GdkGeometryFc.max_width);
	lpStruct->min_height = (*env)->GetIntField(env, lpObject, GdkGeometryFc.min_height);
	lpStruct->min_width = (*env)->GetIntField(env, lpObject, GdkGeometryFc.min_width);
	return lpStruct;
}

void setGdkGeometryFields(JNIEnv *env, jobject lpObject, GdkGeometry *lpStruct)
{
	if (!GdkGeometryFc.cached) cacheGdkGeometryFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.win_gravity, (jint)lpStruct->win_gravity);
	(*env)->SetDoubleField(env, lpObject, GdkGeometryFc.max_aspect, (jdouble)lpStruct->max_aspect);
	(*env)->SetDoubleField(env, lpObject, GdkGeometryFc.min_aspect, (jdouble)lpStruct->min_aspect);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.height_inc, (jint)lpStruct->height_inc);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.width_inc, (jint)lpStruct->width_inc);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.base_height, (jint)lpStruct->base_height);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.base_width, (jint)lpStruct->base_width);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.max_height, (jint)lpStruct->max_height);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.max_width, (jint)lpStruct->max_width);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.min_height, (jint)lpStruct->min_height);
	(*env)->SetIntField(env, lpObject, GdkGeometryFc.min_width, (jint)lpStruct->min_width);
}
#endif

#ifndef NO_GdkImage
typedef struct GdkImage_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID windowing_data, colormap, mem, bits_per_pixel, bpl, bpp, depth, height, width, byte_order, visual, type;
} GdkImage_FID_CACHE;

GdkImage_FID_CACHE GdkImageFc;

void cacheGdkImageFields(JNIEnv *env, jobject lpObject)
{
	if (GdkImageFc.cached) return;
	GdkImageFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkImageFc.windowing_data = (*env)->GetFieldID(env, GdkImageFc.clazz, "windowing_data", "J");
	GdkImageFc.colormap = (*env)->GetFieldID(env, GdkImageFc.clazz, "colormap", "J");
	GdkImageFc.mem = (*env)->GetFieldID(env, GdkImageFc.clazz, "mem", "J");
	GdkImageFc.bits_per_pixel = (*env)->GetFieldID(env, GdkImageFc.clazz, "bits_per_pixel", "S");
	GdkImageFc.bpl = (*env)->GetFieldID(env, GdkImageFc.clazz, "bpl", "S");
	GdkImageFc.bpp = (*env)->GetFieldID(env, GdkImageFc.clazz, "bpp", "S");
	GdkImageFc.depth = (*env)->GetFieldID(env, GdkImageFc.clazz, "depth", "S");
	GdkImageFc.height = (*env)->GetFieldID(env, GdkImageFc.clazz, "height", "I");
	GdkImageFc.width = (*env)->GetFieldID(env, GdkImageFc.clazz, "width", "I");
	GdkImageFc.byte_order = (*env)->GetFieldID(env, GdkImageFc.clazz, "byte_order", "I");
	GdkImageFc.visual = (*env)->GetFieldID(env, GdkImageFc.clazz, "visual", "J");
	GdkImageFc.type = (*env)->GetFieldID(env, GdkImageFc.clazz, "type", "I");
	GdkImageFc.cached = 1;
}

GdkImage *getGdkImageFields(JNIEnv *env, jobject lpObject, GdkImage *lpStruct)
{
	if (!GdkImageFc.cached) cacheGdkImageFields(env, lpObject);
	lpStruct->windowing_data = (gpointer)(*env)->GetLongField(env, lpObject, GdkImageFc.windowing_data);
	lpStruct->colormap = (GdkColormap *)(*env)->GetLongField(env, lpObject, GdkImageFc.colormap);
	lpStruct->mem = (gpointer)(*env)->GetLongField(env, lpObject, GdkImageFc.mem);
	lpStruct->bits_per_pixel = (guint16)(*env)->GetShortField(env, lpObject, GdkImageFc.bits_per_pixel);
	lpStruct->bpl = (guint16)(*env)->GetShortField(env, lpObject, GdkImageFc.bpl);
	lpStruct->bpp = (guint16)(*env)->GetShortField(env, lpObject, GdkImageFc.bpp);
	lpStruct->depth = (guint16)(*env)->GetShortField(env, lpObject, GdkImageFc.depth);
	lpStruct->height = (gint)(*env)->GetIntField(env, lpObject, GdkImageFc.height);
	lpStruct->width = (gint)(*env)->GetIntField(env, lpObject, GdkImageFc.width);
	lpStruct->byte_order = (GdkByteOrder)(*env)->GetIntField(env, lpObject, GdkImageFc.byte_order);
	lpStruct->visual = (GdkVisual *)(*env)->GetLongField(env, lpObject, GdkImageFc.visual);
	lpStruct->type = (GdkImageType)(*env)->GetIntField(env, lpObject, GdkImageFc.type);
	return lpStruct;
}

void setGdkImageFields(JNIEnv *env, jobject lpObject, GdkImage *lpStruct)
{
	if (!GdkImageFc.cached) cacheGdkImageFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GdkImageFc.windowing_data, (jlong)lpStruct->windowing_data);
	(*env)->SetLongField(env, lpObject, GdkImageFc.colormap, (jlong)lpStruct->colormap);
	(*env)->SetLongField(env, lpObject, GdkImageFc.mem, (jlong)lpStruct->mem);
	(*env)->SetShortField(env, lpObject, GdkImageFc.bits_per_pixel, (jshort)lpStruct->bits_per_pixel);
	(*env)->SetShortField(env, lpObject, GdkImageFc.bpl, (jshort)lpStruct->bpl);
	(*env)->SetShortField(env, lpObject, GdkImageFc.bpp, (jshort)lpStruct->bpp);
	(*env)->SetShortField(env, lpObject, GdkImageFc.depth, (jshort)lpStruct->depth);
	(*env)->SetIntField(env, lpObject, GdkImageFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, GdkImageFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, GdkImageFc.byte_order, (jint)lpStruct->byte_order);
	(*env)->SetLongField(env, lpObject, GdkImageFc.visual, (jlong)lpStruct->visual);
	(*env)->SetIntField(env, lpObject, GdkImageFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_GdkRectangle
typedef struct GdkRectangle_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID height, width, y, x;
} GdkRectangle_FID_CACHE;

GdkRectangle_FID_CACHE GdkRectangleFc;

void cacheGdkRectangleFields(JNIEnv *env, jobject lpObject)
{
	if (GdkRectangleFc.cached) return;
	GdkRectangleFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkRectangleFc.height = (*env)->GetFieldID(env, GdkRectangleFc.clazz, "height", "I");
	GdkRectangleFc.width = (*env)->GetFieldID(env, GdkRectangleFc.clazz, "width", "I");
	GdkRectangleFc.y = (*env)->GetFieldID(env, GdkRectangleFc.clazz, "y", "I");
	GdkRectangleFc.x = (*env)->GetFieldID(env, GdkRectangleFc.clazz, "x", "I");
	GdkRectangleFc.cached = 1;
}

GdkRectangle *getGdkRectangleFields(JNIEnv *env, jobject lpObject, GdkRectangle *lpStruct)
{
	if (!GdkRectangleFc.cached) cacheGdkRectangleFields(env, lpObject);
	lpStruct->height = (gint)(*env)->GetIntField(env, lpObject, GdkRectangleFc.height);
	lpStruct->width = (gint)(*env)->GetIntField(env, lpObject, GdkRectangleFc.width);
	lpStruct->y = (gint)(*env)->GetIntField(env, lpObject, GdkRectangleFc.y);
	lpStruct->x = (gint)(*env)->GetIntField(env, lpObject, GdkRectangleFc.x);
	return lpStruct;
}

void setGdkRectangleFields(JNIEnv *env, jobject lpObject, GdkRectangle *lpStruct)
{
	if (!GdkRectangleFc.cached) cacheGdkRectangleFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkRectangleFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, GdkRectangleFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, GdkRectangleFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, GdkRectangleFc.x, (jint)lpStruct->x);
}
#endif

#ifndef NO_GdkVisual
typedef struct GdkVisual_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID blue_prec, blue_shift, blue_mask, green_prec, green_shift, green_mask, red_prec, red_shift, red_mask, bits_per_rgb, colormap_size, byte_order, depth, type;
} GdkVisual_FID_CACHE;

GdkVisual_FID_CACHE GdkVisualFc;

void cacheGdkVisualFields(JNIEnv *env, jobject lpObject)
{
	if (GdkVisualFc.cached) return;
	GdkVisualFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkVisualFc.blue_prec = (*env)->GetFieldID(env, GdkVisualFc.clazz, "blue_prec", "I");
	GdkVisualFc.blue_shift = (*env)->GetFieldID(env, GdkVisualFc.clazz, "blue_shift", "I");
	GdkVisualFc.blue_mask = (*env)->GetFieldID(env, GdkVisualFc.clazz, "blue_mask", "I");
	GdkVisualFc.green_prec = (*env)->GetFieldID(env, GdkVisualFc.clazz, "green_prec", "I");
	GdkVisualFc.green_shift = (*env)->GetFieldID(env, GdkVisualFc.clazz, "green_shift", "I");
	GdkVisualFc.green_mask = (*env)->GetFieldID(env, GdkVisualFc.clazz, "green_mask", "I");
	GdkVisualFc.red_prec = (*env)->GetFieldID(env, GdkVisualFc.clazz, "red_prec", "I");
	GdkVisualFc.red_shift = (*env)->GetFieldID(env, GdkVisualFc.clazz, "red_shift", "I");
	GdkVisualFc.red_mask = (*env)->GetFieldID(env, GdkVisualFc.clazz, "red_mask", "I");
	GdkVisualFc.bits_per_rgb = (*env)->GetFieldID(env, GdkVisualFc.clazz, "bits_per_rgb", "I");
	GdkVisualFc.colormap_size = (*env)->GetFieldID(env, GdkVisualFc.clazz, "colormap_size", "I");
	GdkVisualFc.byte_order = (*env)->GetFieldID(env, GdkVisualFc.clazz, "byte_order", "I");
	GdkVisualFc.depth = (*env)->GetFieldID(env, GdkVisualFc.clazz, "depth", "I");
	GdkVisualFc.type = (*env)->GetFieldID(env, GdkVisualFc.clazz, "type", "I");
	GdkVisualFc.cached = 1;
}

GdkVisual *getGdkVisualFields(JNIEnv *env, jobject lpObject, GdkVisual *lpStruct)
{
	if (!GdkVisualFc.cached) cacheGdkVisualFields(env, lpObject);
	lpStruct->blue_prec = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.blue_prec);
	lpStruct->blue_shift = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.blue_shift);
	lpStruct->blue_mask = (guint32)(*env)->GetIntField(env, lpObject, GdkVisualFc.blue_mask);
	lpStruct->green_prec = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.green_prec);
	lpStruct->green_shift = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.green_shift);
	lpStruct->green_mask = (guint32)(*env)->GetIntField(env, lpObject, GdkVisualFc.green_mask);
	lpStruct->red_prec = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.red_prec);
	lpStruct->red_shift = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.red_shift);
	lpStruct->red_mask = (guint32)(*env)->GetIntField(env, lpObject, GdkVisualFc.red_mask);
	lpStruct->bits_per_rgb = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.bits_per_rgb);
	lpStruct->colormap_size = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.colormap_size);
	lpStruct->byte_order = (GdkByteOrder)(*env)->GetIntField(env, lpObject, GdkVisualFc.byte_order);
	lpStruct->depth = (gint)(*env)->GetIntField(env, lpObject, GdkVisualFc.depth);
	lpStruct->type = (GdkVisualType)(*env)->GetIntField(env, lpObject, GdkVisualFc.type);
	return lpStruct;
}

void setGdkVisualFields(JNIEnv *env, jobject lpObject, GdkVisual *lpStruct)
{
	if (!GdkVisualFc.cached) cacheGdkVisualFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.blue_prec, (jint)lpStruct->blue_prec);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.blue_shift, (jint)lpStruct->blue_shift);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.blue_mask, (jint)lpStruct->blue_mask);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.green_prec, (jint)lpStruct->green_prec);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.green_shift, (jint)lpStruct->green_shift);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.green_mask, (jint)lpStruct->green_mask);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.red_prec, (jint)lpStruct->red_prec);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.red_shift, (jint)lpStruct->red_shift);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.red_mask, (jint)lpStruct->red_mask);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.bits_per_rgb, (jint)lpStruct->bits_per_rgb);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.colormap_size, (jint)lpStruct->colormap_size);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.byte_order, (jint)lpStruct->byte_order);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.depth, (jint)lpStruct->depth);
	(*env)->SetIntField(env, lpObject, GdkVisualFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_GdkWindowAttr
typedef struct GdkWindowAttr_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID override_redirect, wmclass_class, wmclass_name, cursor, window_type, colormap, visual, wclass, height, width, y, x, event_mask, title;
} GdkWindowAttr_FID_CACHE;

GdkWindowAttr_FID_CACHE GdkWindowAttrFc;

void cacheGdkWindowAttrFields(JNIEnv *env, jobject lpObject)
{
	if (GdkWindowAttrFc.cached) return;
	GdkWindowAttrFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GdkWindowAttrFc.override_redirect = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "override_redirect", "Z");
	GdkWindowAttrFc.wmclass_class = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "wmclass_class", "J");
	GdkWindowAttrFc.wmclass_name = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "wmclass_name", "J");
	GdkWindowAttrFc.cursor = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "cursor", "J");
	GdkWindowAttrFc.window_type = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "window_type", "I");
	GdkWindowAttrFc.colormap = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "colormap", "J");
	GdkWindowAttrFc.visual = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "visual", "J");
	GdkWindowAttrFc.wclass = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "wclass", "I");
	GdkWindowAttrFc.height = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "height", "I");
	GdkWindowAttrFc.width = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "width", "I");
	GdkWindowAttrFc.y = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "y", "I");
	GdkWindowAttrFc.x = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "x", "I");
	GdkWindowAttrFc.event_mask = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "event_mask", "I");
	GdkWindowAttrFc.title = (*env)->GetFieldID(env, GdkWindowAttrFc.clazz, "title", "J");
	GdkWindowAttrFc.cached = 1;
}

GdkWindowAttr *getGdkWindowAttrFields(JNIEnv *env, jobject lpObject, GdkWindowAttr *lpStruct)
{
	if (!GdkWindowAttrFc.cached) cacheGdkWindowAttrFields(env, lpObject);
	lpStruct->override_redirect = (*env)->GetBooleanField(env, lpObject, GdkWindowAttrFc.override_redirect);
	lpStruct->wmclass_class = (gchar *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.wmclass_class);
	lpStruct->wmclass_name = (gchar *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.wmclass_name);
	lpStruct->cursor = (GdkCursor *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.cursor);
	lpStruct->window_type = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.window_type);
	lpStruct->colormap = (GdkColormap *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.colormap);
	lpStruct->visual = (GdkVisual *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.visual);
	lpStruct->wclass = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.wclass);
	lpStruct->height = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.width);
	lpStruct->y = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.x);
	lpStruct->event_mask = (*env)->GetIntField(env, lpObject, GdkWindowAttrFc.event_mask);
	lpStruct->title = (gchar *)(*env)->GetLongField(env, lpObject, GdkWindowAttrFc.title);
	return lpStruct;
}

void setGdkWindowAttrFields(JNIEnv *env, jobject lpObject, GdkWindowAttr *lpStruct)
{
	if (!GdkWindowAttrFc.cached) cacheGdkWindowAttrFields(env, lpObject);
	(*env)->SetBooleanField(env, lpObject, GdkWindowAttrFc.override_redirect, (jboolean)lpStruct->override_redirect);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.wmclass_class, (jlong)lpStruct->wmclass_class);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.wmclass_name, (jlong)lpStruct->wmclass_name);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.cursor, (jlong)lpStruct->cursor);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.window_type, (jint)lpStruct->window_type);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.colormap, (jlong)lpStruct->colormap);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.visual, (jlong)lpStruct->visual);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.wclass, (jint)lpStruct->wclass);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.x, (jint)lpStruct->x);
	(*env)->SetIntField(env, lpObject, GdkWindowAttrFc.event_mask, (jint)lpStruct->event_mask);
	(*env)->SetLongField(env, lpObject, GdkWindowAttrFc.title, (jlong)lpStruct->title);
}
#endif

#ifndef NO_GtkAdjustment
typedef struct GtkAdjustment_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID page_size, page_increment, step_increment, value, upper, lower;
} GtkAdjustment_FID_CACHE;

GtkAdjustment_FID_CACHE GtkAdjustmentFc;

void cacheGtkAdjustmentFields(JNIEnv *env, jobject lpObject)
{
	if (GtkAdjustmentFc.cached) return;
	GtkAdjustmentFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkAdjustmentFc.page_size = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "page_size", "D");
	GtkAdjustmentFc.page_increment = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "page_increment", "D");
	GtkAdjustmentFc.step_increment = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "step_increment", "D");
	GtkAdjustmentFc.value = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "value", "D");
	GtkAdjustmentFc.upper = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "upper", "D");
	GtkAdjustmentFc.lower = (*env)->GetFieldID(env, GtkAdjustmentFc.clazz, "lower", "D");
	GtkAdjustmentFc.cached = 1;
}

GtkAdjustment *getGtkAdjustmentFields(JNIEnv *env, jobject lpObject, GtkAdjustment *lpStruct)
{
	if (!GtkAdjustmentFc.cached) cacheGtkAdjustmentFields(env, lpObject);
	lpStruct->page_size = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.page_size);
	lpStruct->page_increment = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.page_increment);
	lpStruct->step_increment = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.step_increment);
	lpStruct->value = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.value);
	lpStruct->upper = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.upper);
	lpStruct->lower = (gdouble)(*env)->GetDoubleField(env, lpObject, GtkAdjustmentFc.lower);
	return lpStruct;
}

void setGtkAdjustmentFields(JNIEnv *env, jobject lpObject, GtkAdjustment *lpStruct)
{
	if (!GtkAdjustmentFc.cached) cacheGtkAdjustmentFields(env, lpObject);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.page_size, (jdouble)lpStruct->page_size);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.page_increment, (jdouble)lpStruct->page_increment);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.step_increment, (jdouble)lpStruct->step_increment);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.value, (jdouble)lpStruct->value);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.upper, (jdouble)lpStruct->upper);
	(*env)->SetDoubleField(env, lpObject, GtkAdjustmentFc.lower, (jdouble)lpStruct->lower);
}
#endif

#ifndef NO_GtkAllocation
typedef struct GtkAllocation_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID height, width, y, x;
} GtkAllocation_FID_CACHE;

GtkAllocation_FID_CACHE GtkAllocationFc;

void cacheGtkAllocationFields(JNIEnv *env, jobject lpObject)
{
	if (GtkAllocationFc.cached) return;
	GtkAllocationFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkAllocationFc.height = (*env)->GetFieldID(env, GtkAllocationFc.clazz, "height", "I");
	GtkAllocationFc.width = (*env)->GetFieldID(env, GtkAllocationFc.clazz, "width", "I");
	GtkAllocationFc.y = (*env)->GetFieldID(env, GtkAllocationFc.clazz, "y", "I");
	GtkAllocationFc.x = (*env)->GetFieldID(env, GtkAllocationFc.clazz, "x", "I");
	GtkAllocationFc.cached = 1;
}

GtkAllocation *getGtkAllocationFields(JNIEnv *env, jobject lpObject, GtkAllocation *lpStruct)
{
	if (!GtkAllocationFc.cached) cacheGtkAllocationFields(env, lpObject);
	lpStruct->height = (*env)->GetIntField(env, lpObject, GtkAllocationFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, GtkAllocationFc.width);
	lpStruct->y = (*env)->GetIntField(env, lpObject, GtkAllocationFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, GtkAllocationFc.x);
	return lpStruct;
}

void setGtkAllocationFields(JNIEnv *env, jobject lpObject, GtkAllocation *lpStruct)
{
	if (!GtkAllocationFc.cached) cacheGtkAllocationFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkAllocationFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, GtkAllocationFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, GtkAllocationFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, GtkAllocationFc.x, (jint)lpStruct->x);
}
#endif

#ifndef NO_GtkBorder
typedef struct GtkBorder_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID bottom, top, right, left;
} GtkBorder_FID_CACHE;

GtkBorder_FID_CACHE GtkBorderFc;

void cacheGtkBorderFields(JNIEnv *env, jobject lpObject)
{
	if (GtkBorderFc.cached) return;
	GtkBorderFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkBorderFc.bottom = (*env)->GetFieldID(env, GtkBorderFc.clazz, "bottom", "I");
	GtkBorderFc.top = (*env)->GetFieldID(env, GtkBorderFc.clazz, "top", "I");
	GtkBorderFc.right = (*env)->GetFieldID(env, GtkBorderFc.clazz, "right", "I");
	GtkBorderFc.left = (*env)->GetFieldID(env, GtkBorderFc.clazz, "left", "I");
	GtkBorderFc.cached = 1;
}

GtkBorder *getGtkBorderFields(JNIEnv *env, jobject lpObject, GtkBorder *lpStruct)
{
	if (!GtkBorderFc.cached) cacheGtkBorderFields(env, lpObject);
	lpStruct->bottom = (*env)->GetIntField(env, lpObject, GtkBorderFc.bottom);
	lpStruct->top = (*env)->GetIntField(env, lpObject, GtkBorderFc.top);
	lpStruct->right = (*env)->GetIntField(env, lpObject, GtkBorderFc.right);
	lpStruct->left = (*env)->GetIntField(env, lpObject, GtkBorderFc.left);
	return lpStruct;
}

void setGtkBorderFields(JNIEnv *env, jobject lpObject, GtkBorder *lpStruct)
{
	if (!GtkBorderFc.cached) cacheGtkBorderFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkBorderFc.bottom, (jint)lpStruct->bottom);
	(*env)->SetIntField(env, lpObject, GtkBorderFc.top, (jint)lpStruct->top);
	(*env)->SetIntField(env, lpObject, GtkBorderFc.right, (jint)lpStruct->right);
	(*env)->SetIntField(env, lpObject, GtkBorderFc.left, (jint)lpStruct->left);
}
#endif

#ifndef NO_GtkCellRendererClass
typedef struct GtkCellRendererClass_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID get_size, render;
} GtkCellRendererClass_FID_CACHE;

GtkCellRendererClass_FID_CACHE GtkCellRendererClassFc;

void cacheGtkCellRendererClassFields(JNIEnv *env, jobject lpObject)
{
	if (GtkCellRendererClassFc.cached) return;
	GtkCellRendererClassFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkCellRendererClassFc.get_size = (*env)->GetFieldID(env, GtkCellRendererClassFc.clazz, "get_size", "J");
	GtkCellRendererClassFc.render = (*env)->GetFieldID(env, GtkCellRendererClassFc.clazz, "render", "J");
	GtkCellRendererClassFc.cached = 1;
}

GtkCellRendererClass *getGtkCellRendererClassFields(JNIEnv *env, jobject lpObject, GtkCellRendererClass *lpStruct)
{
	if (!GtkCellRendererClassFc.cached) cacheGtkCellRendererClassFields(env, lpObject);
	lpStruct->get_size = (void(*)())(*env)->GetLongField(env, lpObject, GtkCellRendererClassFc.get_size);
	lpStruct->render = (void(*)())(*env)->GetLongField(env, lpObject, GtkCellRendererClassFc.render);
	return lpStruct;
}

void setGtkCellRendererClassFields(JNIEnv *env, jobject lpObject, GtkCellRendererClass *lpStruct)
{
	if (!GtkCellRendererClassFc.cached) cacheGtkCellRendererClassFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkCellRendererClassFc.get_size, (jlong)lpStruct->get_size);
	(*env)->SetLongField(env, lpObject, GtkCellRendererClassFc.render, (jlong)lpStruct->render);
}
#endif

#ifndef NO_GtkColorSelectionDialog
typedef struct GtkColorSelectionDialog_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID help_button, cancel_button, ok_button, colorsel;
} GtkColorSelectionDialog_FID_CACHE;

GtkColorSelectionDialog_FID_CACHE GtkColorSelectionDialogFc;

void cacheGtkColorSelectionDialogFields(JNIEnv *env, jobject lpObject)
{
	if (GtkColorSelectionDialogFc.cached) return;
	GtkColorSelectionDialogFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkColorSelectionDialogFc.help_button = (*env)->GetFieldID(env, GtkColorSelectionDialogFc.clazz, "help_button", "J");
	GtkColorSelectionDialogFc.cancel_button = (*env)->GetFieldID(env, GtkColorSelectionDialogFc.clazz, "cancel_button", "J");
	GtkColorSelectionDialogFc.ok_button = (*env)->GetFieldID(env, GtkColorSelectionDialogFc.clazz, "ok_button", "J");
	GtkColorSelectionDialogFc.colorsel = (*env)->GetFieldID(env, GtkColorSelectionDialogFc.clazz, "colorsel", "J");
	GtkColorSelectionDialogFc.cached = 1;
}

GtkColorSelectionDialog *getGtkColorSelectionDialogFields(JNIEnv *env, jobject lpObject, GtkColorSelectionDialog *lpStruct)
{
	if (!GtkColorSelectionDialogFc.cached) cacheGtkColorSelectionDialogFields(env, lpObject);
	lpStruct->help_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkColorSelectionDialogFc.help_button);
	lpStruct->cancel_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkColorSelectionDialogFc.cancel_button);
	lpStruct->ok_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkColorSelectionDialogFc.ok_button);
	lpStruct->colorsel = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkColorSelectionDialogFc.colorsel);
	return lpStruct;
}

void setGtkColorSelectionDialogFields(JNIEnv *env, jobject lpObject, GtkColorSelectionDialog *lpStruct)
{
	if (!GtkColorSelectionDialogFc.cached) cacheGtkColorSelectionDialogFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkColorSelectionDialogFc.help_button, (jlong)lpStruct->help_button);
	(*env)->SetLongField(env, lpObject, GtkColorSelectionDialogFc.cancel_button, (jlong)lpStruct->cancel_button);
	(*env)->SetLongField(env, lpObject, GtkColorSelectionDialogFc.ok_button, (jlong)lpStruct->ok_button);
	(*env)->SetLongField(env, lpObject, GtkColorSelectionDialogFc.colorsel, (jlong)lpStruct->colorsel);
}
#endif

#ifndef NO_GtkCombo
typedef struct GtkCombo_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID list, entry;
} GtkCombo_FID_CACHE;

GtkCombo_FID_CACHE GtkComboFc;

void cacheGtkComboFields(JNIEnv *env, jobject lpObject)
{
	if (GtkComboFc.cached) return;
	GtkComboFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkComboFc.list = (*env)->GetFieldID(env, GtkComboFc.clazz, "list", "J");
	GtkComboFc.entry = (*env)->GetFieldID(env, GtkComboFc.clazz, "entry", "J");
	GtkComboFc.cached = 1;
}

GtkCombo *getGtkComboFields(JNIEnv *env, jobject lpObject, GtkCombo *lpStruct)
{
	if (!GtkComboFc.cached) cacheGtkComboFields(env, lpObject);
	lpStruct->list = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkComboFc.list);
	lpStruct->entry = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkComboFc.entry);
	return lpStruct;
}

void setGtkComboFields(JNIEnv *env, jobject lpObject, GtkCombo *lpStruct)
{
	if (!GtkComboFc.cached) cacheGtkComboFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkComboFc.list, (jlong)lpStruct->list);
	(*env)->SetLongField(env, lpObject, GtkComboFc.entry, (jlong)lpStruct->entry);
}
#endif

#ifndef NO_GtkFileSelection
typedef struct GtkFileSelection_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID action_area, button_area, fileop_ren_file, fileop_del_file, fileop_c_dir, cmpl_state, fileop_file, fileop_entry, fileop_dialog, history_list, history_menu, history_pulldown, help_button, cancel_button, ok_button, main_vbox, selection_text, selection_entry, file_list, dir_list;
} GtkFileSelection_FID_CACHE;

GtkFileSelection_FID_CACHE GtkFileSelectionFc;

void cacheGtkFileSelectionFields(JNIEnv *env, jobject lpObject)
{
	if (GtkFileSelectionFc.cached) return;
	GtkFileSelectionFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkFileSelectionFc.action_area = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "action_area", "J");
	GtkFileSelectionFc.button_area = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "button_area", "J");
	GtkFileSelectionFc.fileop_ren_file = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_ren_file", "J");
	GtkFileSelectionFc.fileop_del_file = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_del_file", "J");
	GtkFileSelectionFc.fileop_c_dir = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_c_dir", "J");
	GtkFileSelectionFc.cmpl_state = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "cmpl_state", "J");
	GtkFileSelectionFc.fileop_file = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_file", "J");
	GtkFileSelectionFc.fileop_entry = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_entry", "J");
	GtkFileSelectionFc.fileop_dialog = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "fileop_dialog", "J");
	GtkFileSelectionFc.history_list = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "history_list", "J");
	GtkFileSelectionFc.history_menu = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "history_menu", "J");
	GtkFileSelectionFc.history_pulldown = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "history_pulldown", "J");
	GtkFileSelectionFc.help_button = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "help_button", "J");
	GtkFileSelectionFc.cancel_button = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "cancel_button", "J");
	GtkFileSelectionFc.ok_button = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "ok_button", "J");
	GtkFileSelectionFc.main_vbox = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "main_vbox", "J");
	GtkFileSelectionFc.selection_text = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "selection_text", "J");
	GtkFileSelectionFc.selection_entry = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "selection_entry", "J");
	GtkFileSelectionFc.file_list = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "file_list", "J");
	GtkFileSelectionFc.dir_list = (*env)->GetFieldID(env, GtkFileSelectionFc.clazz, "dir_list", "J");
	GtkFileSelectionFc.cached = 1;
}

GtkFileSelection *getGtkFileSelectionFields(JNIEnv *env, jobject lpObject, GtkFileSelection *lpStruct)
{
	if (!GtkFileSelectionFc.cached) cacheGtkFileSelectionFields(env, lpObject);
	lpStruct->action_area = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.action_area);
	lpStruct->button_area = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.button_area);
	lpStruct->fileop_ren_file = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_ren_file);
	lpStruct->fileop_del_file = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_del_file);
	lpStruct->fileop_c_dir = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_c_dir);
	lpStruct->cmpl_state = (gpointer)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.cmpl_state);
	lpStruct->fileop_file = (gchar *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_file);
	lpStruct->fileop_entry = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_entry);
	lpStruct->fileop_dialog = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.fileop_dialog);
	lpStruct->history_list = (GList *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.history_list);
	lpStruct->history_menu = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.history_menu);
	lpStruct->history_pulldown = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.history_pulldown);
	lpStruct->help_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.help_button);
	lpStruct->cancel_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.cancel_button);
	lpStruct->ok_button = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.ok_button);
	lpStruct->main_vbox = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.main_vbox);
	lpStruct->selection_text = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.selection_text);
	lpStruct->selection_entry = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.selection_entry);
	lpStruct->file_list = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.file_list);
	lpStruct->dir_list = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkFileSelectionFc.dir_list);
	return lpStruct;
}

void setGtkFileSelectionFields(JNIEnv *env, jobject lpObject, GtkFileSelection *lpStruct)
{
	if (!GtkFileSelectionFc.cached) cacheGtkFileSelectionFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.action_area, (jlong)lpStruct->action_area);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.button_area, (jlong)lpStruct->button_area);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_ren_file, (jlong)lpStruct->fileop_ren_file);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_del_file, (jlong)lpStruct->fileop_del_file);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_c_dir, (jlong)lpStruct->fileop_c_dir);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.cmpl_state, (jlong)lpStruct->cmpl_state);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_file, (jlong)lpStruct->fileop_file);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_entry, (jlong)lpStruct->fileop_entry);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.fileop_dialog, (jlong)lpStruct->fileop_dialog);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.history_list, (jlong)lpStruct->history_list);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.history_menu, (jlong)lpStruct->history_menu);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.history_pulldown, (jlong)lpStruct->history_pulldown);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.help_button, (jlong)lpStruct->help_button);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.cancel_button, (jlong)lpStruct->cancel_button);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.ok_button, (jlong)lpStruct->ok_button);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.main_vbox, (jlong)lpStruct->main_vbox);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.selection_text, (jlong)lpStruct->selection_text);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.selection_entry, (jlong)lpStruct->selection_entry);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.file_list, (jlong)lpStruct->file_list);
	(*env)->SetLongField(env, lpObject, GtkFileSelectionFc.dir_list, (jlong)lpStruct->dir_list);
}
#endif

#ifndef NO_GtkFixed
typedef struct GtkFixed_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID children;
} GtkFixed_FID_CACHE;

GtkFixed_FID_CACHE GtkFixedFc;

void cacheGtkFixedFields(JNIEnv *env, jobject lpObject)
{
	if (GtkFixedFc.cached) return;
	GtkFixedFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkFixedFc.children = (*env)->GetFieldID(env, GtkFixedFc.clazz, "children", "J");
	GtkFixedFc.cached = 1;
}

GtkFixed *getGtkFixedFields(JNIEnv *env, jobject lpObject, GtkFixed *lpStruct)
{
	if (!GtkFixedFc.cached) cacheGtkFixedFields(env, lpObject);
	lpStruct->children = (GList *)(*env)->GetLongField(env, lpObject, GtkFixedFc.children);
	return lpStruct;
}

void setGtkFixedFields(JNIEnv *env, jobject lpObject, GtkFixed *lpStruct)
{
	if (!GtkFixedFc.cached) cacheGtkFixedFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkFixedFc.children, (jlong)lpStruct->children);
}
#endif

#ifndef NO_GtkRequisition
typedef struct GtkRequisition_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID height, width;
} GtkRequisition_FID_CACHE;

GtkRequisition_FID_CACHE GtkRequisitionFc;

void cacheGtkRequisitionFields(JNIEnv *env, jobject lpObject)
{
	if (GtkRequisitionFc.cached) return;
	GtkRequisitionFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkRequisitionFc.height = (*env)->GetFieldID(env, GtkRequisitionFc.clazz, "height", "I");
	GtkRequisitionFc.width = (*env)->GetFieldID(env, GtkRequisitionFc.clazz, "width", "I");
	GtkRequisitionFc.cached = 1;
}

GtkRequisition *getGtkRequisitionFields(JNIEnv *env, jobject lpObject, GtkRequisition *lpStruct)
{
	if (!GtkRequisitionFc.cached) cacheGtkRequisitionFields(env, lpObject);
	lpStruct->height = (*env)->GetIntField(env, lpObject, GtkRequisitionFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, GtkRequisitionFc.width);
	return lpStruct;
}

void setGtkRequisitionFields(JNIEnv *env, jobject lpObject, GtkRequisition *lpStruct)
{
	if (!GtkRequisitionFc.cached) cacheGtkRequisitionFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkRequisitionFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, GtkRequisitionFc.width, (jint)lpStruct->width);
}
#endif

#ifndef NO_GtkSelectionData
typedef struct GtkSelectionData_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID length, data, format, type, target, selection;
} GtkSelectionData_FID_CACHE;

GtkSelectionData_FID_CACHE GtkSelectionDataFc;

void cacheGtkSelectionDataFields(JNIEnv *env, jobject lpObject)
{
	if (GtkSelectionDataFc.cached) return;
	GtkSelectionDataFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkSelectionDataFc.length = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "length", "I");
	GtkSelectionDataFc.data = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "data", "J");
	GtkSelectionDataFc.format = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "format", "I");
	GtkSelectionDataFc.type = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "type", "J");
	GtkSelectionDataFc.target = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "target", "J");
	GtkSelectionDataFc.selection = (*env)->GetFieldID(env, GtkSelectionDataFc.clazz, "selection", "J");
	GtkSelectionDataFc.cached = 1;
}

GtkSelectionData *getGtkSelectionDataFields(JNIEnv *env, jobject lpObject, GtkSelectionData *lpStruct)
{
	if (!GtkSelectionDataFc.cached) cacheGtkSelectionDataFields(env, lpObject);
	lpStruct->length = (gint)(*env)->GetIntField(env, lpObject, GtkSelectionDataFc.length);
	lpStruct->data = (guchar *)(*env)->GetLongField(env, lpObject, GtkSelectionDataFc.data);
	lpStruct->format = (gint)(*env)->GetIntField(env, lpObject, GtkSelectionDataFc.format);
	lpStruct->type = (GdkAtom)(*env)->GetLongField(env, lpObject, GtkSelectionDataFc.type);
	lpStruct->target = (GdkAtom)(*env)->GetLongField(env, lpObject, GtkSelectionDataFc.target);
	lpStruct->selection = (GdkAtom)(*env)->GetLongField(env, lpObject, GtkSelectionDataFc.selection);
	return lpStruct;
}

void setGtkSelectionDataFields(JNIEnv *env, jobject lpObject, GtkSelectionData *lpStruct)
{
	if (!GtkSelectionDataFc.cached) cacheGtkSelectionDataFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkSelectionDataFc.length, (jint)lpStruct->length);
	(*env)->SetLongField(env, lpObject, GtkSelectionDataFc.data, (jlong)lpStruct->data);
	(*env)->SetIntField(env, lpObject, GtkSelectionDataFc.format, (jint)lpStruct->format);
	(*env)->SetLongField(env, lpObject, GtkSelectionDataFc.type, (jlong)lpStruct->type);
	(*env)->SetLongField(env, lpObject, GtkSelectionDataFc.target, (jlong)lpStruct->target);
	(*env)->SetLongField(env, lpObject, GtkSelectionDataFc.selection, (jlong)lpStruct->selection);
}
#endif

#ifndef NO_GtkTargetEntry
typedef struct GtkTargetEntry_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID info, flags, target;
} GtkTargetEntry_FID_CACHE;

GtkTargetEntry_FID_CACHE GtkTargetEntryFc;

void cacheGtkTargetEntryFields(JNIEnv *env, jobject lpObject)
{
	if (GtkTargetEntryFc.cached) return;
	GtkTargetEntryFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkTargetEntryFc.info = (*env)->GetFieldID(env, GtkTargetEntryFc.clazz, "info", "I");
	GtkTargetEntryFc.flags = (*env)->GetFieldID(env, GtkTargetEntryFc.clazz, "flags", "I");
	GtkTargetEntryFc.target = (*env)->GetFieldID(env, GtkTargetEntryFc.clazz, "target", "J");
	GtkTargetEntryFc.cached = 1;
}

GtkTargetEntry *getGtkTargetEntryFields(JNIEnv *env, jobject lpObject, GtkTargetEntry *lpStruct)
{
	if (!GtkTargetEntryFc.cached) cacheGtkTargetEntryFields(env, lpObject);
	lpStruct->info = (guint)(*env)->GetIntField(env, lpObject, GtkTargetEntryFc.info);
	lpStruct->flags = (guint)(*env)->GetIntField(env, lpObject, GtkTargetEntryFc.flags);
	lpStruct->target = (gchar *)(*env)->GetLongField(env, lpObject, GtkTargetEntryFc.target);
	return lpStruct;
}

void setGtkTargetEntryFields(JNIEnv *env, jobject lpObject, GtkTargetEntry *lpStruct)
{
	if (!GtkTargetEntryFc.cached) cacheGtkTargetEntryFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkTargetEntryFc.info, (jint)lpStruct->info);
	(*env)->SetIntField(env, lpObject, GtkTargetEntryFc.flags, (jint)lpStruct->flags);
	(*env)->SetLongField(env, lpObject, GtkTargetEntryFc.target, (jlong)lpStruct->target);
}
#endif

#ifndef NO_GtkTargetPair
typedef struct GtkTargetPair_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID info, flags, target;
} GtkTargetPair_FID_CACHE;

GtkTargetPair_FID_CACHE GtkTargetPairFc;

void cacheGtkTargetPairFields(JNIEnv *env, jobject lpObject)
{
	if (GtkTargetPairFc.cached) return;
	GtkTargetPairFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkTargetPairFc.info = (*env)->GetFieldID(env, GtkTargetPairFc.clazz, "info", "I");
	GtkTargetPairFc.flags = (*env)->GetFieldID(env, GtkTargetPairFc.clazz, "flags", "I");
	GtkTargetPairFc.target = (*env)->GetFieldID(env, GtkTargetPairFc.clazz, "target", "J");
	GtkTargetPairFc.cached = 1;
}

GtkTargetPair *getGtkTargetPairFields(JNIEnv *env, jobject lpObject, GtkTargetPair *lpStruct)
{
	if (!GtkTargetPairFc.cached) cacheGtkTargetPairFields(env, lpObject);
	lpStruct->info = (guint)(*env)->GetIntField(env, lpObject, GtkTargetPairFc.info);
	lpStruct->flags = (guint)(*env)->GetIntField(env, lpObject, GtkTargetPairFc.flags);
	lpStruct->target = (GdkAtom)(*env)->GetLongField(env, lpObject, GtkTargetPairFc.target);
	return lpStruct;
}

void setGtkTargetPairFields(JNIEnv *env, jobject lpObject, GtkTargetPair *lpStruct)
{
	if (!GtkTargetPairFc.cached) cacheGtkTargetPairFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, GtkTargetPairFc.info, (jint)lpStruct->info);
	(*env)->SetIntField(env, lpObject, GtkTargetPairFc.flags, (jint)lpStruct->flags);
	(*env)->SetLongField(env, lpObject, GtkTargetPairFc.target, (jlong)lpStruct->target);
}
#endif

#ifndef NO_GtkWidgetClass
typedef struct GtkWidgetClass_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID screen_changed, get_accessible, show_help, popup_menu, drag_data_received, drag_drop, drag_motion, drag_leave, drag_data_delete, drag_data_get, drag_end, drag_begin, selection_received, selection_get, window_state_event, no_expose_event, client_event, visibility_notify_event, proximity_out_event, proximity_in_event, selection_notify_event, selection_request_event, selection_clear_event, property_notify_event, unmap_event, map_event, focus_out_event, focus_in_event, configure_event, leave_notify_event, enter_notify_event, key_release_event, key_press_event, expose_event, destroy_event, delete_event, motion_notify_event, scroll_event, button_release_event, button_press_event, event, focus, grab_focus, mnemonic_activate, child_notify, grab_notify, direction_changed, style_set, hierarchy_changed, parent_set, state_changed, size_allocate, size_request, unrealize, realize, unmap, map, hide_all, hide, show_all, show, dispatch_child_properties_changed, set_scroll_adjustments_signal, activate_signal;
} GtkWidgetClass_FID_CACHE;

GtkWidgetClass_FID_CACHE GtkWidgetClassFc;

void cacheGtkWidgetClassFields(JNIEnv *env, jobject lpObject)
{
	if (GtkWidgetClassFc.cached) return;
	cacheGObjectClassFields(env, lpObject);
	GtkWidgetClassFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkWidgetClassFc.screen_changed = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "screen_changed", "J");
	GtkWidgetClassFc.get_accessible = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "get_accessible", "J");
	GtkWidgetClassFc.show_help = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "show_help", "J");
	GtkWidgetClassFc.popup_menu = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "popup_menu", "J");
	GtkWidgetClassFc.drag_data_received = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_data_received", "J");
	GtkWidgetClassFc.drag_drop = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_drop", "J");
	GtkWidgetClassFc.drag_motion = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_motion", "J");
	GtkWidgetClassFc.drag_leave = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_leave", "J");
	GtkWidgetClassFc.drag_data_delete = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_data_delete", "J");
	GtkWidgetClassFc.drag_data_get = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_data_get", "J");
	GtkWidgetClassFc.drag_end = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_end", "J");
	GtkWidgetClassFc.drag_begin = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "drag_begin", "J");
	GtkWidgetClassFc.selection_received = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "selection_received", "J");
	GtkWidgetClassFc.selection_get = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "selection_get", "J");
	GtkWidgetClassFc.window_state_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "window_state_event", "J");
	GtkWidgetClassFc.no_expose_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "no_expose_event", "J");
	GtkWidgetClassFc.client_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "client_event", "J");
	GtkWidgetClassFc.visibility_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "visibility_notify_event", "J");
	GtkWidgetClassFc.proximity_out_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "proximity_out_event", "J");
	GtkWidgetClassFc.proximity_in_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "proximity_in_event", "J");
	GtkWidgetClassFc.selection_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "selection_notify_event", "J");
	GtkWidgetClassFc.selection_request_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "selection_request_event", "J");
	GtkWidgetClassFc.selection_clear_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "selection_clear_event", "J");
	GtkWidgetClassFc.property_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "property_notify_event", "J");
	GtkWidgetClassFc.unmap_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "unmap_event", "J");
	GtkWidgetClassFc.map_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "map_event", "J");
	GtkWidgetClassFc.focus_out_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "focus_out_event", "J");
	GtkWidgetClassFc.focus_in_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "focus_in_event", "J");
	GtkWidgetClassFc.configure_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "configure_event", "J");
	GtkWidgetClassFc.leave_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "leave_notify_event", "J");
	GtkWidgetClassFc.enter_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "enter_notify_event", "J");
	GtkWidgetClassFc.key_release_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "key_release_event", "J");
	GtkWidgetClassFc.key_press_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "key_press_event", "J");
	GtkWidgetClassFc.expose_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "expose_event", "J");
	GtkWidgetClassFc.destroy_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "destroy_event", "J");
	GtkWidgetClassFc.delete_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "delete_event", "J");
	GtkWidgetClassFc.motion_notify_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "motion_notify_event", "J");
	GtkWidgetClassFc.scroll_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "scroll_event", "J");
	GtkWidgetClassFc.button_release_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "button_release_event", "J");
	GtkWidgetClassFc.button_press_event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "button_press_event", "J");
	GtkWidgetClassFc.event = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "event", "J");
	GtkWidgetClassFc.focus = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "focus", "J");
	GtkWidgetClassFc.grab_focus = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "grab_focus", "J");
	GtkWidgetClassFc.mnemonic_activate = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "mnemonic_activate", "J");
	GtkWidgetClassFc.child_notify = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "child_notify", "J");
	GtkWidgetClassFc.grab_notify = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "grab_notify", "J");
	GtkWidgetClassFc.direction_changed = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "direction_changed", "J");
	GtkWidgetClassFc.style_set = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "style_set", "J");
	GtkWidgetClassFc.hierarchy_changed = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "hierarchy_changed", "J");
	GtkWidgetClassFc.parent_set = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "parent_set", "J");
	GtkWidgetClassFc.state_changed = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "state_changed", "J");
	GtkWidgetClassFc.size_allocate = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "size_allocate", "J");
	GtkWidgetClassFc.size_request = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "size_request", "J");
	GtkWidgetClassFc.unrealize = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "unrealize", "J");
	GtkWidgetClassFc.realize = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "realize", "J");
	GtkWidgetClassFc.unmap = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "unmap", "J");
	GtkWidgetClassFc.map = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "map", "J");
	GtkWidgetClassFc.hide_all = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "hide_all", "J");
	GtkWidgetClassFc.hide = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "hide", "J");
	GtkWidgetClassFc.show_all = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "show_all", "J");
	GtkWidgetClassFc.show = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "show", "J");
	GtkWidgetClassFc.dispatch_child_properties_changed = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "dispatch_child_properties_changed", "J");
	GtkWidgetClassFc.set_scroll_adjustments_signal = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "set_scroll_adjustments_signal", "I");
	GtkWidgetClassFc.activate_signal = (*env)->GetFieldID(env, GtkWidgetClassFc.clazz, "activate_signal", "I");
	GtkWidgetClassFc.cached = 1;
}

GtkWidgetClass *getGtkWidgetClassFields(JNIEnv *env, jobject lpObject, GtkWidgetClass *lpStruct)
{
	if (!GtkWidgetClassFc.cached) cacheGtkWidgetClassFields(env, lpObject);
	getGObjectClassFields(env, lpObject, (GObjectClass *)lpStruct);
	lpStruct->screen_changed = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.screen_changed);
	lpStruct->get_accessible = (AtkObject*(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.get_accessible);
	lpStruct->show_help = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.show_help);
	lpStruct->popup_menu = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.popup_menu);
	lpStruct->drag_data_received = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_data_received);
	lpStruct->drag_drop = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_drop);
	lpStruct->drag_motion = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_motion);
	lpStruct->drag_leave = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_leave);
	lpStruct->drag_data_delete = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_data_delete);
	lpStruct->drag_data_get = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_data_get);
	lpStruct->drag_end = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_end);
	lpStruct->drag_begin = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.drag_begin);
	lpStruct->selection_received = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.selection_received);
	lpStruct->selection_get = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.selection_get);
	lpStruct->window_state_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.window_state_event);
	lpStruct->no_expose_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.no_expose_event);
	lpStruct->client_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.client_event);
	lpStruct->visibility_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.visibility_notify_event);
	lpStruct->proximity_out_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.proximity_out_event);
	lpStruct->proximity_in_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.proximity_in_event);
	lpStruct->selection_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.selection_notify_event);
	lpStruct->selection_request_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.selection_request_event);
	lpStruct->selection_clear_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.selection_clear_event);
	lpStruct->property_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.property_notify_event);
	lpStruct->unmap_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.unmap_event);
	lpStruct->map_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.map_event);
	lpStruct->focus_out_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.focus_out_event);
	lpStruct->focus_in_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.focus_in_event);
	lpStruct->configure_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.configure_event);
	lpStruct->leave_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.leave_notify_event);
	lpStruct->enter_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.enter_notify_event);
	lpStruct->key_release_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.key_release_event);
	lpStruct->key_press_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.key_press_event);
	lpStruct->expose_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.expose_event);
	lpStruct->destroy_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.destroy_event);
	lpStruct->delete_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.delete_event);
	lpStruct->motion_notify_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.motion_notify_event);
	lpStruct->scroll_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.scroll_event);
	lpStruct->button_release_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.button_release_event);
	lpStruct->button_press_event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.button_press_event);
	lpStruct->event = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.event);
	lpStruct->focus = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.focus);
	lpStruct->grab_focus = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.grab_focus);
	lpStruct->mnemonic_activate = (gboolean(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.mnemonic_activate);
	lpStruct->child_notify = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.child_notify);
	lpStruct->grab_notify = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.grab_notify);
	lpStruct->direction_changed = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.direction_changed);
	lpStruct->style_set = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.style_set);
	lpStruct->hierarchy_changed = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.hierarchy_changed);
	lpStruct->parent_set = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.parent_set);
	lpStruct->state_changed = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.state_changed);
	lpStruct->size_allocate = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.size_allocate);
	lpStruct->size_request = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.size_request);
	lpStruct->unrealize = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.unrealize);
	lpStruct->realize = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.realize);
	lpStruct->unmap = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.unmap);
	lpStruct->map = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.map);
	lpStruct->hide_all = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.hide_all);
	lpStruct->hide = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.hide);
	lpStruct->show_all = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.show_all);
	lpStruct->show = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.show);
	lpStruct->dispatch_child_properties_changed = (void(*)())(*env)->GetLongField(env, lpObject, GtkWidgetClassFc.dispatch_child_properties_changed);
	lpStruct->set_scroll_adjustments_signal = (*env)->GetIntField(env, lpObject, GtkWidgetClassFc.set_scroll_adjustments_signal);
	lpStruct->activate_signal = (*env)->GetIntField(env, lpObject, GtkWidgetClassFc.activate_signal);
	return lpStruct;
}

void setGtkWidgetClassFields(JNIEnv *env, jobject lpObject, GtkWidgetClass *lpStruct)
{
	if (!GtkWidgetClassFc.cached) cacheGtkWidgetClassFields(env, lpObject);
	setGObjectClassFields(env, lpObject, (GObjectClass *)lpStruct);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.screen_changed, (jlong)lpStruct->screen_changed);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.get_accessible, (jlong)lpStruct->get_accessible);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.show_help, (jlong)lpStruct->show_help);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.popup_menu, (jlong)lpStruct->popup_menu);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_data_received, (jlong)lpStruct->drag_data_received);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_drop, (jlong)lpStruct->drag_drop);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_motion, (jlong)lpStruct->drag_motion);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_leave, (jlong)lpStruct->drag_leave);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_data_delete, (jlong)lpStruct->drag_data_delete);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_data_get, (jlong)lpStruct->drag_data_get);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_end, (jlong)lpStruct->drag_end);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.drag_begin, (jlong)lpStruct->drag_begin);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.selection_received, (jlong)lpStruct->selection_received);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.selection_get, (jlong)lpStruct->selection_get);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.window_state_event, (jlong)lpStruct->window_state_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.no_expose_event, (jlong)lpStruct->no_expose_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.client_event, (jlong)lpStruct->client_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.visibility_notify_event, (jlong)lpStruct->visibility_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.proximity_out_event, (jlong)lpStruct->proximity_out_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.proximity_in_event, (jlong)lpStruct->proximity_in_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.selection_notify_event, (jlong)lpStruct->selection_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.selection_request_event, (jlong)lpStruct->selection_request_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.selection_clear_event, (jlong)lpStruct->selection_clear_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.property_notify_event, (jlong)lpStruct->property_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.unmap_event, (jlong)lpStruct->unmap_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.map_event, (jlong)lpStruct->map_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.focus_out_event, (jlong)lpStruct->focus_out_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.focus_in_event, (jlong)lpStruct->focus_in_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.configure_event, (jlong)lpStruct->configure_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.leave_notify_event, (jlong)lpStruct->leave_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.enter_notify_event, (jlong)lpStruct->enter_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.key_release_event, (jlong)lpStruct->key_release_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.key_press_event, (jlong)lpStruct->key_press_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.expose_event, (jlong)lpStruct->expose_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.destroy_event, (jlong)lpStruct->destroy_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.delete_event, (jlong)lpStruct->delete_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.motion_notify_event, (jlong)lpStruct->motion_notify_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.scroll_event, (jlong)lpStruct->scroll_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.button_release_event, (jlong)lpStruct->button_release_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.button_press_event, (jlong)lpStruct->button_press_event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.event, (jlong)lpStruct->event);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.focus, (jlong)lpStruct->focus);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.grab_focus, (jlong)lpStruct->grab_focus);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.mnemonic_activate, (jlong)lpStruct->mnemonic_activate);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.child_notify, (jlong)lpStruct->child_notify);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.grab_notify, (jlong)lpStruct->grab_notify);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.direction_changed, (jlong)lpStruct->direction_changed);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.style_set, (jlong)lpStruct->style_set);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.hierarchy_changed, (jlong)lpStruct->hierarchy_changed);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.parent_set, (jlong)lpStruct->parent_set);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.state_changed, (jlong)lpStruct->state_changed);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.size_allocate, (jlong)lpStruct->size_allocate);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.size_request, (jlong)lpStruct->size_request);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.unrealize, (jlong)lpStruct->unrealize);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.realize, (jlong)lpStruct->realize);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.unmap, (jlong)lpStruct->unmap);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.map, (jlong)lpStruct->map);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.hide_all, (jlong)lpStruct->hide_all);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.hide, (jlong)lpStruct->hide);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.show_all, (jlong)lpStruct->show_all);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.show, (jlong)lpStruct->show);
	(*env)->SetLongField(env, lpObject, GtkWidgetClassFc.dispatch_child_properties_changed, (jlong)lpStruct->dispatch_child_properties_changed);
	(*env)->SetIntField(env, lpObject, GtkWidgetClassFc.set_scroll_adjustments_signal, (jint)lpStruct->set_scroll_adjustments_signal);
	(*env)->SetIntField(env, lpObject, GtkWidgetClassFc.activate_signal, (jint)lpStruct->activate_signal);
}
#endif

#ifndef NO_PangoAttribute
typedef struct PangoAttribute_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID end_index, start_index, klass;
} PangoAttribute_FID_CACHE;

PangoAttribute_FID_CACHE PangoAttributeFc;

void cachePangoAttributeFields(JNIEnv *env, jobject lpObject)
{
	if (PangoAttributeFc.cached) return;
	PangoAttributeFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoAttributeFc.end_index = (*env)->GetFieldID(env, PangoAttributeFc.clazz, "end_index", "I");
	PangoAttributeFc.start_index = (*env)->GetFieldID(env, PangoAttributeFc.clazz, "start_index", "I");
	PangoAttributeFc.klass = (*env)->GetFieldID(env, PangoAttributeFc.clazz, "klass", "J");
	PangoAttributeFc.cached = 1;
}

PangoAttribute *getPangoAttributeFields(JNIEnv *env, jobject lpObject, PangoAttribute *lpStruct)
{
	if (!PangoAttributeFc.cached) cachePangoAttributeFields(env, lpObject);
	lpStruct->end_index = (*env)->GetIntField(env, lpObject, PangoAttributeFc.end_index);
	lpStruct->start_index = (*env)->GetIntField(env, lpObject, PangoAttributeFc.start_index);
	lpStruct->klass = (const PangoAttrClass *)(*env)->GetLongField(env, lpObject, PangoAttributeFc.klass);
	return lpStruct;
}

void setPangoAttributeFields(JNIEnv *env, jobject lpObject, PangoAttribute *lpStruct)
{
	if (!PangoAttributeFc.cached) cachePangoAttributeFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, PangoAttributeFc.end_index, (jint)lpStruct->end_index);
	(*env)->SetIntField(env, lpObject, PangoAttributeFc.start_index, (jint)lpStruct->start_index);
	(*env)->SetLongField(env, lpObject, PangoAttributeFc.klass, (jlong)lpStruct->klass);
}
#endif

#ifndef NO_PangoItem
typedef struct PangoItem_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID analysis_extra_attrs, analysis_language, analysis_level, analysis_font, analysis_lang_engine, analysis_shape_engine, num_chars, length, offset;
} PangoItem_FID_CACHE;

PangoItem_FID_CACHE PangoItemFc;

void cachePangoItemFields(JNIEnv *env, jobject lpObject)
{
	if (PangoItemFc.cached) return;
	PangoItemFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoItemFc.analysis_extra_attrs = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_extra_attrs", "J");
	PangoItemFc.analysis_language = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_language", "J");
	PangoItemFc.analysis_level = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_level", "B");
	PangoItemFc.analysis_font = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_font", "J");
	PangoItemFc.analysis_lang_engine = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_lang_engine", "J");
	PangoItemFc.analysis_shape_engine = (*env)->GetFieldID(env, PangoItemFc.clazz, "analysis_shape_engine", "J");
	PangoItemFc.num_chars = (*env)->GetFieldID(env, PangoItemFc.clazz, "num_chars", "I");
	PangoItemFc.length = (*env)->GetFieldID(env, PangoItemFc.clazz, "length", "I");
	PangoItemFc.offset = (*env)->GetFieldID(env, PangoItemFc.clazz, "offset", "I");
	PangoItemFc.cached = 1;
}

PangoItem *getPangoItemFields(JNIEnv *env, jobject lpObject, PangoItem *lpStruct)
{
	if (!PangoItemFc.cached) cachePangoItemFields(env, lpObject);
	lpStruct->analysis.extra_attrs = (GSList *)(*env)->GetLongField(env, lpObject, PangoItemFc.analysis_extra_attrs);
	lpStruct->analysis.language = (PangoLanguage *)(*env)->GetLongField(env, lpObject, PangoItemFc.analysis_language);
	lpStruct->analysis.level = (*env)->GetByteField(env, lpObject, PangoItemFc.analysis_level);
	lpStruct->analysis.font = (PangoFont *)(*env)->GetLongField(env, lpObject, PangoItemFc.analysis_font);
	lpStruct->analysis.lang_engine = (PangoEngineLang *)(*env)->GetLongField(env, lpObject, PangoItemFc.analysis_lang_engine);
	lpStruct->analysis.shape_engine = (PangoEngineShape *)(*env)->GetLongField(env, lpObject, PangoItemFc.analysis_shape_engine);
	lpStruct->num_chars = (*env)->GetIntField(env, lpObject, PangoItemFc.num_chars);
	lpStruct->length = (*env)->GetIntField(env, lpObject, PangoItemFc.length);
	lpStruct->offset = (*env)->GetIntField(env, lpObject, PangoItemFc.offset);
	return lpStruct;
}

void setPangoItemFields(JNIEnv *env, jobject lpObject, PangoItem *lpStruct)
{
	if (!PangoItemFc.cached) cachePangoItemFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, PangoItemFc.analysis_extra_attrs, (jlong)lpStruct->analysis.extra_attrs);
	(*env)->SetLongField(env, lpObject, PangoItemFc.analysis_language, (jlong)lpStruct->analysis.language);
	(*env)->SetByteField(env, lpObject, PangoItemFc.analysis_level, (jbyte)lpStruct->analysis.level);
	(*env)->SetLongField(env, lpObject, PangoItemFc.analysis_font, (jlong)lpStruct->analysis.font);
	(*env)->SetLongField(env, lpObject, PangoItemFc.analysis_lang_engine, (jlong)lpStruct->analysis.lang_engine);
	(*env)->SetLongField(env, lpObject, PangoItemFc.analysis_shape_engine, (jlong)lpStruct->analysis.shape_engine);
	(*env)->SetIntField(env, lpObject, PangoItemFc.num_chars, (jint)lpStruct->num_chars);
	(*env)->SetIntField(env, lpObject, PangoItemFc.length, (jint)lpStruct->length);
	(*env)->SetIntField(env, lpObject, PangoItemFc.offset, (jint)lpStruct->offset);
}
#endif

#ifndef NO_PangoLayoutLine
typedef struct PangoLayoutLine_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID runs, length, start_index, layout;
} PangoLayoutLine_FID_CACHE;

PangoLayoutLine_FID_CACHE PangoLayoutLineFc;

void cachePangoLayoutLineFields(JNIEnv *env, jobject lpObject)
{
	if (PangoLayoutLineFc.cached) return;
	PangoLayoutLineFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoLayoutLineFc.runs = (*env)->GetFieldID(env, PangoLayoutLineFc.clazz, "runs", "J");
	PangoLayoutLineFc.length = (*env)->GetFieldID(env, PangoLayoutLineFc.clazz, "length", "I");
	PangoLayoutLineFc.start_index = (*env)->GetFieldID(env, PangoLayoutLineFc.clazz, "start_index", "I");
	PangoLayoutLineFc.layout = (*env)->GetFieldID(env, PangoLayoutLineFc.clazz, "layout", "J");
	PangoLayoutLineFc.cached = 1;
}

PangoLayoutLine *getPangoLayoutLineFields(JNIEnv *env, jobject lpObject, PangoLayoutLine *lpStruct)
{
	if (!PangoLayoutLineFc.cached) cachePangoLayoutLineFields(env, lpObject);
	lpStruct->runs = (GSList *)(*env)->GetLongField(env, lpObject, PangoLayoutLineFc.runs);
	lpStruct->length = (*env)->GetIntField(env, lpObject, PangoLayoutLineFc.length);
	lpStruct->start_index = (*env)->GetIntField(env, lpObject, PangoLayoutLineFc.start_index);
	lpStruct->layout = (PangoLayout *)(*env)->GetLongField(env, lpObject, PangoLayoutLineFc.layout);
	return lpStruct;
}

void setPangoLayoutLineFields(JNIEnv *env, jobject lpObject, PangoLayoutLine *lpStruct)
{
	if (!PangoLayoutLineFc.cached) cachePangoLayoutLineFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, PangoLayoutLineFc.runs, (jlong)lpStruct->runs);
	(*env)->SetIntField(env, lpObject, PangoLayoutLineFc.length, (jint)lpStruct->length);
	(*env)->SetIntField(env, lpObject, PangoLayoutLineFc.start_index, (jint)lpStruct->start_index);
	(*env)->SetLongField(env, lpObject, PangoLayoutLineFc.layout, (jlong)lpStruct->layout);
}
#endif

#ifndef NO_PangoLayoutRun
typedef struct PangoLayoutRun_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID glyphs, item;
} PangoLayoutRun_FID_CACHE;

PangoLayoutRun_FID_CACHE PangoLayoutRunFc;

void cachePangoLayoutRunFields(JNIEnv *env, jobject lpObject)
{
	if (PangoLayoutRunFc.cached) return;
	PangoLayoutRunFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoLayoutRunFc.glyphs = (*env)->GetFieldID(env, PangoLayoutRunFc.clazz, "glyphs", "J");
	PangoLayoutRunFc.item = (*env)->GetFieldID(env, PangoLayoutRunFc.clazz, "item", "J");
	PangoLayoutRunFc.cached = 1;
}

PangoLayoutRun *getPangoLayoutRunFields(JNIEnv *env, jobject lpObject, PangoLayoutRun *lpStruct)
{
	if (!PangoLayoutRunFc.cached) cachePangoLayoutRunFields(env, lpObject);
	lpStruct->glyphs = (PangoGlyphString *)(*env)->GetLongField(env, lpObject, PangoLayoutRunFc.glyphs);
	lpStruct->item = (PangoItem *)(*env)->GetLongField(env, lpObject, PangoLayoutRunFc.item);
	return lpStruct;
}

void setPangoLayoutRunFields(JNIEnv *env, jobject lpObject, PangoLayoutRun *lpStruct)
{
	if (!PangoLayoutRunFc.cached) cachePangoLayoutRunFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, PangoLayoutRunFc.glyphs, (jlong)lpStruct->glyphs);
	(*env)->SetLongField(env, lpObject, PangoLayoutRunFc.item, (jlong)lpStruct->item);
}
#endif

#ifndef NO_PangoLogAttr
typedef struct PangoLogAttr_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID is_sentence_end, is_sentence_start, is_sentence_boundary, is_word_end, is_word_start, is_cursor_position, is_white, is_char_break, is_mandatory_break, is_line_break;
} PangoLogAttr_FID_CACHE;

PangoLogAttr_FID_CACHE PangoLogAttrFc;

void cachePangoLogAttrFields(JNIEnv *env, jobject lpObject)
{
	if (PangoLogAttrFc.cached) return;
	PangoLogAttrFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoLogAttrFc.is_sentence_end = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_sentence_end", "Z");
	PangoLogAttrFc.is_sentence_start = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_sentence_start", "Z");
	PangoLogAttrFc.is_sentence_boundary = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_sentence_boundary", "Z");
	PangoLogAttrFc.is_word_end = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_word_end", "Z");
	PangoLogAttrFc.is_word_start = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_word_start", "Z");
	PangoLogAttrFc.is_cursor_position = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_cursor_position", "Z");
	PangoLogAttrFc.is_white = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_white", "Z");
	PangoLogAttrFc.is_char_break = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_char_break", "Z");
	PangoLogAttrFc.is_mandatory_break = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_mandatory_break", "Z");
	PangoLogAttrFc.is_line_break = (*env)->GetFieldID(env, PangoLogAttrFc.clazz, "is_line_break", "Z");
	PangoLogAttrFc.cached = 1;
}

PangoLogAttr *getPangoLogAttrFields(JNIEnv *env, jobject lpObject, PangoLogAttr *lpStruct)
{
	if (!PangoLogAttrFc.cached) cachePangoLogAttrFields(env, lpObject);
	lpStruct->is_sentence_end = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_end);
	lpStruct->is_sentence_start = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_start);
	lpStruct->is_sentence_boundary = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_boundary);
	lpStruct->is_word_end = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_word_end);
	lpStruct->is_word_start = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_word_start);
	lpStruct->is_cursor_position = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_cursor_position);
	lpStruct->is_white = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_white);
	lpStruct->is_char_break = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_char_break);
	lpStruct->is_mandatory_break = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_mandatory_break);
	lpStruct->is_line_break = (*env)->GetBooleanField(env, lpObject, PangoLogAttrFc.is_line_break);
	return lpStruct;
}

void setPangoLogAttrFields(JNIEnv *env, jobject lpObject, PangoLogAttr *lpStruct)
{
	if (!PangoLogAttrFc.cached) cachePangoLogAttrFields(env, lpObject);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_end, (jboolean)lpStruct->is_sentence_end);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_start, (jboolean)lpStruct->is_sentence_start);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_sentence_boundary, (jboolean)lpStruct->is_sentence_boundary);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_word_end, (jboolean)lpStruct->is_word_end);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_word_start, (jboolean)lpStruct->is_word_start);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_cursor_position, (jboolean)lpStruct->is_cursor_position);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_white, (jboolean)lpStruct->is_white);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_char_break, (jboolean)lpStruct->is_char_break);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_mandatory_break, (jboolean)lpStruct->is_mandatory_break);
	(*env)->SetBooleanField(env, lpObject, PangoLogAttrFc.is_line_break, (jboolean)lpStruct->is_line_break);
}
#endif

#ifndef NO_PangoRectangle
typedef struct PangoRectangle_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID height, width, y, x;
} PangoRectangle_FID_CACHE;

PangoRectangle_FID_CACHE PangoRectangleFc;

void cachePangoRectangleFields(JNIEnv *env, jobject lpObject)
{
	if (PangoRectangleFc.cached) return;
	PangoRectangleFc.clazz = (*env)->GetObjectClass(env, lpObject);
	PangoRectangleFc.height = (*env)->GetFieldID(env, PangoRectangleFc.clazz, "height", "I");
	PangoRectangleFc.width = (*env)->GetFieldID(env, PangoRectangleFc.clazz, "width", "I");
	PangoRectangleFc.y = (*env)->GetFieldID(env, PangoRectangleFc.clazz, "y", "I");
	PangoRectangleFc.x = (*env)->GetFieldID(env, PangoRectangleFc.clazz, "x", "I");
	PangoRectangleFc.cached = 1;
}

PangoRectangle *getPangoRectangleFields(JNIEnv *env, jobject lpObject, PangoRectangle *lpStruct)
{
	if (!PangoRectangleFc.cached) cachePangoRectangleFields(env, lpObject);
	lpStruct->height = (*env)->GetIntField(env, lpObject, PangoRectangleFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, PangoRectangleFc.width);
	lpStruct->y = (*env)->GetIntField(env, lpObject, PangoRectangleFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, PangoRectangleFc.x);
	return lpStruct;
}

void setPangoRectangleFields(JNIEnv *env, jobject lpObject, PangoRectangle *lpStruct)
{
	if (!PangoRectangleFc.cached) cachePangoRectangleFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, PangoRectangleFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, PangoRectangleFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, PangoRectangleFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, PangoRectangleFc.x, (jint)lpStruct->x);
}
#endif

#ifndef NO_XAnyEvent
typedef struct XAnyEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID window, display, send_event, serial;
} XAnyEvent_FID_CACHE;

XAnyEvent_FID_CACHE XAnyEventFc;

void cacheXAnyEventFields(JNIEnv *env, jobject lpObject)
{
	if (XAnyEventFc.cached) return;
	cacheXEventFields(env, lpObject);
	XAnyEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XAnyEventFc.window = (*env)->GetFieldID(env, XAnyEventFc.clazz, "window", "J");
	XAnyEventFc.display = (*env)->GetFieldID(env, XAnyEventFc.clazz, "display", "J");
	XAnyEventFc.send_event = (*env)->GetFieldID(env, XAnyEventFc.clazz, "send_event", "I");
	XAnyEventFc.serial = (*env)->GetFieldID(env, XAnyEventFc.clazz, "serial", "J");
	XAnyEventFc.cached = 1;
}

XAnyEvent *getXAnyEventFields(JNIEnv *env, jobject lpObject, XAnyEvent *lpStruct)
{
	if (!XAnyEventFc.cached) cacheXAnyEventFields(env, lpObject);
	getXEventFields(env, lpObject, (XEvent *)lpStruct);
	lpStruct->window = (Window)(*env)->GetLongField(env, lpObject, XAnyEventFc.window);
	lpStruct->display = (Display *)(*env)->GetLongField(env, lpObject, XAnyEventFc.display);
	lpStruct->send_event = (*env)->GetIntField(env, lpObject, XAnyEventFc.send_event);
	lpStruct->serial = (*env)->GetLongField(env, lpObject, XAnyEventFc.serial);
	return lpStruct;
}

void setXAnyEventFields(JNIEnv *env, jobject lpObject, XAnyEvent *lpStruct)
{
	if (!XAnyEventFc.cached) cacheXAnyEventFields(env, lpObject);
	setXEventFields(env, lpObject, (XEvent *)lpStruct);
	(*env)->SetLongField(env, lpObject, XAnyEventFc.window, (jlong)lpStruct->window);
	(*env)->SetLongField(env, lpObject, XAnyEventFc.display, (jlong)lpStruct->display);
	(*env)->SetIntField(env, lpObject, XAnyEventFc.send_event, (jint)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, XAnyEventFc.serial, (jlong)lpStruct->serial);
}
#endif

#ifndef NO_XButtonEvent
typedef struct XButtonEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID same_screen, button, state, y_root, x_root, y, x, time, subwindow, root;
} XButtonEvent_FID_CACHE;

XButtonEvent_FID_CACHE XButtonEventFc;

void cacheXButtonEventFields(JNIEnv *env, jobject lpObject)
{
	if (XButtonEventFc.cached) return;
	cacheXAnyEventFields(env, lpObject);
	XButtonEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XButtonEventFc.same_screen = (*env)->GetFieldID(env, XButtonEventFc.clazz, "same_screen", "I");
	XButtonEventFc.button = (*env)->GetFieldID(env, XButtonEventFc.clazz, "button", "I");
	XButtonEventFc.state = (*env)->GetFieldID(env, XButtonEventFc.clazz, "state", "I");
	XButtonEventFc.y_root = (*env)->GetFieldID(env, XButtonEventFc.clazz, "y_root", "I");
	XButtonEventFc.x_root = (*env)->GetFieldID(env, XButtonEventFc.clazz, "x_root", "I");
	XButtonEventFc.y = (*env)->GetFieldID(env, XButtonEventFc.clazz, "y", "I");
	XButtonEventFc.x = (*env)->GetFieldID(env, XButtonEventFc.clazz, "x", "I");
	XButtonEventFc.time = (*env)->GetFieldID(env, XButtonEventFc.clazz, "time", "I");
	XButtonEventFc.subwindow = (*env)->GetFieldID(env, XButtonEventFc.clazz, "subwindow", "I");
	XButtonEventFc.root = (*env)->GetFieldID(env, XButtonEventFc.clazz, "root", "I");
	XButtonEventFc.cached = 1;
}

XButtonEvent *getXButtonEventFields(JNIEnv *env, jobject lpObject, XButtonEvent *lpStruct)
{
	if (!XButtonEventFc.cached) cacheXButtonEventFields(env, lpObject);
	getXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	lpStruct->same_screen = (*env)->GetIntField(env, lpObject, XButtonEventFc.same_screen);
	lpStruct->button = (*env)->GetIntField(env, lpObject, XButtonEventFc.button);
	lpStruct->state = (*env)->GetIntField(env, lpObject, XButtonEventFc.state);
	lpStruct->y_root = (*env)->GetIntField(env, lpObject, XButtonEventFc.y_root);
	lpStruct->x_root = (*env)->GetIntField(env, lpObject, XButtonEventFc.x_root);
	lpStruct->y = (*env)->GetIntField(env, lpObject, XButtonEventFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, XButtonEventFc.x);
	lpStruct->time = (*env)->GetIntField(env, lpObject, XButtonEventFc.time);
	lpStruct->subwindow = (*env)->GetIntField(env, lpObject, XButtonEventFc.subwindow);
	lpStruct->root = (*env)->GetIntField(env, lpObject, XButtonEventFc.root);
	return lpStruct;
}

void setXButtonEventFields(JNIEnv *env, jobject lpObject, XButtonEvent *lpStruct)
{
	if (!XButtonEventFc.cached) cacheXButtonEventFields(env, lpObject);
	setXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.same_screen, (jint)lpStruct->same_screen);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.button, (jint)lpStruct->button);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.state, (jint)lpStruct->state);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.y_root, (jint)lpStruct->y_root);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.x_root, (jint)lpStruct->x_root);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.x, (jint)lpStruct->x);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.time, (jint)lpStruct->time);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.subwindow, (jint)lpStruct->subwindow);
	(*env)->SetIntField(env, lpObject, XButtonEventFc.root, (jint)lpStruct->root);
}
#endif

#ifndef NO_XClientMessageEvent
typedef struct XClientMessageEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID data, format, message_type, window, display, send_event, serial, type;
} XClientMessageEvent_FID_CACHE;

XClientMessageEvent_FID_CACHE XClientMessageEventFc;

void cacheXClientMessageEventFields(JNIEnv *env, jobject lpObject)
{
	if (XClientMessageEventFc.cached) return;
	XClientMessageEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XClientMessageEventFc.data = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "data", "[J");
	XClientMessageEventFc.format = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "format", "I");
	XClientMessageEventFc.message_type = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "message_type", "J");
	XClientMessageEventFc.window = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "window", "J");
	XClientMessageEventFc.display = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "display", "J");
	XClientMessageEventFc.send_event = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "send_event", "Z");
	XClientMessageEventFc.serial = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "serial", "J");
	XClientMessageEventFc.type = (*env)->GetFieldID(env, XClientMessageEventFc.clazz, "type", "I");
	XClientMessageEventFc.cached = 1;
}

XClientMessageEvent *getXClientMessageEventFields(JNIEnv *env, jobject lpObject, XClientMessageEvent *lpStruct)
{
	if (!XClientMessageEventFc.cached) cacheXClientMessageEventFields(env, lpObject);
	{
	jlongArray lpObject1 = (jlongArray)(*env)->GetObjectField(env, lpObject, XClientMessageEventFc.data);
	(*env)->GetLongArrayRegion(env, lpObject1, 0, sizeof(lpStruct->data.l) / 8, (jlong *)lpStruct->data.l);
	}
	lpStruct->format = (*env)->GetIntField(env, lpObject, XClientMessageEventFc.format);
	lpStruct->message_type = (Atom)(*env)->GetLongField(env, lpObject, XClientMessageEventFc.message_type);
	lpStruct->window = (Window)(*env)->GetLongField(env, lpObject, XClientMessageEventFc.window);
	lpStruct->display = (Display *)(*env)->GetLongField(env, lpObject, XClientMessageEventFc.display);
	lpStruct->send_event = (*env)->GetBooleanField(env, lpObject, XClientMessageEventFc.send_event);
	lpStruct->serial = (*env)->GetLongField(env, lpObject, XClientMessageEventFc.serial);
	lpStruct->type = (*env)->GetIntField(env, lpObject, XClientMessageEventFc.type);
	return lpStruct;
}

void setXClientMessageEventFields(JNIEnv *env, jobject lpObject, XClientMessageEvent *lpStruct)
{
	if (!XClientMessageEventFc.cached) cacheXClientMessageEventFields(env, lpObject);
	{
	jlongArray lpObject1 = (jlongArray)(*env)->GetObjectField(env, lpObject, XClientMessageEventFc.data);
	(*env)->SetLongArrayRegion(env, lpObject1, 0, sizeof(lpStruct->data.l) / 8, (jlong *)lpStruct->data.l);
	}
	(*env)->SetIntField(env, lpObject, XClientMessageEventFc.format, (jint)lpStruct->format);
	(*env)->SetLongField(env, lpObject, XClientMessageEventFc.message_type, (jlong)lpStruct->message_type);
	(*env)->SetLongField(env, lpObject, XClientMessageEventFc.window, (jlong)lpStruct->window);
	(*env)->SetLongField(env, lpObject, XClientMessageEventFc.display, (jlong)lpStruct->display);
	(*env)->SetBooleanField(env, lpObject, XClientMessageEventFc.send_event, (jboolean)lpStruct->send_event);
	(*env)->SetLongField(env, lpObject, XClientMessageEventFc.serial, (jlong)lpStruct->serial);
	(*env)->SetIntField(env, lpObject, XClientMessageEventFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_XCrossingEvent
typedef struct XCrossingEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID state, focus, same_screen, detail, mode, y_root, x_root, y, x, time, subwindow, root;
} XCrossingEvent_FID_CACHE;

XCrossingEvent_FID_CACHE XCrossingEventFc;

void cacheXCrossingEventFields(JNIEnv *env, jobject lpObject)
{
	if (XCrossingEventFc.cached) return;
	cacheXAnyEventFields(env, lpObject);
	XCrossingEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XCrossingEventFc.state = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "state", "I");
	XCrossingEventFc.focus = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "focus", "Z");
	XCrossingEventFc.same_screen = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "same_screen", "Z");
	XCrossingEventFc.detail = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "detail", "I");
	XCrossingEventFc.mode = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "mode", "I");
	XCrossingEventFc.y_root = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "y_root", "I");
	XCrossingEventFc.x_root = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "x_root", "I");
	XCrossingEventFc.y = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "y", "I");
	XCrossingEventFc.x = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "x", "I");
	XCrossingEventFc.time = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "time", "I");
	XCrossingEventFc.subwindow = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "subwindow", "J");
	XCrossingEventFc.root = (*env)->GetFieldID(env, XCrossingEventFc.clazz, "root", "J");
	XCrossingEventFc.cached = 1;
}

XCrossingEvent *getXCrossingEventFields(JNIEnv *env, jobject lpObject, XCrossingEvent *lpStruct)
{
	if (!XCrossingEventFc.cached) cacheXCrossingEventFields(env, lpObject);
	getXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	lpStruct->state = (unsigned int)(*env)->GetIntField(env, lpObject, XCrossingEventFc.state);
	lpStruct->focus = (Bool)(*env)->GetBooleanField(env, lpObject, XCrossingEventFc.focus);
	lpStruct->same_screen = (Bool)(*env)->GetBooleanField(env, lpObject, XCrossingEventFc.same_screen);
	lpStruct->detail = (*env)->GetIntField(env, lpObject, XCrossingEventFc.detail);
	lpStruct->mode = (*env)->GetIntField(env, lpObject, XCrossingEventFc.mode);
	lpStruct->y_root = (*env)->GetIntField(env, lpObject, XCrossingEventFc.y_root);
	lpStruct->x_root = (*env)->GetIntField(env, lpObject, XCrossingEventFc.x_root);
	lpStruct->y = (*env)->GetIntField(env, lpObject, XCrossingEventFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, XCrossingEventFc.x);
	lpStruct->time = (Time)(*env)->GetIntField(env, lpObject, XCrossingEventFc.time);
	lpStruct->subwindow = (Window)(*env)->GetLongField(env, lpObject, XCrossingEventFc.subwindow);
	lpStruct->root = (Window)(*env)->GetLongField(env, lpObject, XCrossingEventFc.root);
	return lpStruct;
}

void setXCrossingEventFields(JNIEnv *env, jobject lpObject, XCrossingEvent *lpStruct)
{
	if (!XCrossingEventFc.cached) cacheXCrossingEventFields(env, lpObject);
	setXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.state, (jint)lpStruct->state);
	(*env)->SetBooleanField(env, lpObject, XCrossingEventFc.focus, (jboolean)lpStruct->focus);
	(*env)->SetBooleanField(env, lpObject, XCrossingEventFc.same_screen, (jboolean)lpStruct->same_screen);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.detail, (jint)lpStruct->detail);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.mode, (jint)lpStruct->mode);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.y_root, (jint)lpStruct->y_root);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.x_root, (jint)lpStruct->x_root);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.x, (jint)lpStruct->x);
	(*env)->SetIntField(env, lpObject, XCrossingEventFc.time, (jint)lpStruct->time);
	(*env)->SetLongField(env, lpObject, XCrossingEventFc.subwindow, (jlong)lpStruct->subwindow);
	(*env)->SetLongField(env, lpObject, XCrossingEventFc.root, (jlong)lpStruct->root);
}
#endif

#ifndef NO_XEvent
typedef struct XEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID type;
} XEvent_FID_CACHE;

XEvent_FID_CACHE XEventFc;

void cacheXEventFields(JNIEnv *env, jobject lpObject)
{
	if (XEventFc.cached) return;
	XEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XEventFc.type = (*env)->GetFieldID(env, XEventFc.clazz, "type", "I");
	XEventFc.cached = 1;
}

XEvent *getXEventFields(JNIEnv *env, jobject lpObject, XEvent *lpStruct)
{
	if (!XEventFc.cached) cacheXEventFields(env, lpObject);
	lpStruct->type = (*env)->GetIntField(env, lpObject, XEventFc.type);
	return lpStruct;
}

void setXEventFields(JNIEnv *env, jobject lpObject, XEvent *lpStruct)
{
	if (!XEventFc.cached) cacheXEventFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, XEventFc.type, (jint)lpStruct->type);
}
#endif

#ifndef NO_XExposeEvent
typedef struct XExposeEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID count, height, width, y, x;
} XExposeEvent_FID_CACHE;

XExposeEvent_FID_CACHE XExposeEventFc;

void cacheXExposeEventFields(JNIEnv *env, jobject lpObject)
{
	if (XExposeEventFc.cached) return;
	cacheXAnyEventFields(env, lpObject);
	XExposeEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XExposeEventFc.count = (*env)->GetFieldID(env, XExposeEventFc.clazz, "count", "I");
	XExposeEventFc.height = (*env)->GetFieldID(env, XExposeEventFc.clazz, "height", "I");
	XExposeEventFc.width = (*env)->GetFieldID(env, XExposeEventFc.clazz, "width", "I");
	XExposeEventFc.y = (*env)->GetFieldID(env, XExposeEventFc.clazz, "y", "I");
	XExposeEventFc.x = (*env)->GetFieldID(env, XExposeEventFc.clazz, "x", "I");
	XExposeEventFc.cached = 1;
}

XExposeEvent *getXExposeEventFields(JNIEnv *env, jobject lpObject, XExposeEvent *lpStruct)
{
	if (!XExposeEventFc.cached) cacheXExposeEventFields(env, lpObject);
	getXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	lpStruct->count = (*env)->GetIntField(env, lpObject, XExposeEventFc.count);
	lpStruct->height = (*env)->GetIntField(env, lpObject, XExposeEventFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, XExposeEventFc.width);
	lpStruct->y = (*env)->GetIntField(env, lpObject, XExposeEventFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, XExposeEventFc.x);
	return lpStruct;
}

void setXExposeEventFields(JNIEnv *env, jobject lpObject, XExposeEvent *lpStruct)
{
	if (!XExposeEventFc.cached) cacheXExposeEventFields(env, lpObject);
	setXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, XExposeEventFc.count, (jint)lpStruct->count);
	(*env)->SetIntField(env, lpObject, XExposeEventFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, XExposeEventFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, XExposeEventFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, XExposeEventFc.x, (jint)lpStruct->x);
}
#endif

#ifndef NO_XFocusChangeEvent
typedef struct XFocusChangeEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID detail, mode;
} XFocusChangeEvent_FID_CACHE;

XFocusChangeEvent_FID_CACHE XFocusChangeEventFc;

void cacheXFocusChangeEventFields(JNIEnv *env, jobject lpObject)
{
	if (XFocusChangeEventFc.cached) return;
	cacheXAnyEventFields(env, lpObject);
	XFocusChangeEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XFocusChangeEventFc.detail = (*env)->GetFieldID(env, XFocusChangeEventFc.clazz, "detail", "I");
	XFocusChangeEventFc.mode = (*env)->GetFieldID(env, XFocusChangeEventFc.clazz, "mode", "I");
	XFocusChangeEventFc.cached = 1;
}

XFocusChangeEvent *getXFocusChangeEventFields(JNIEnv *env, jobject lpObject, XFocusChangeEvent *lpStruct)
{
	if (!XFocusChangeEventFc.cached) cacheXFocusChangeEventFields(env, lpObject);
	getXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	lpStruct->detail = (*env)->GetIntField(env, lpObject, XFocusChangeEventFc.detail);
	lpStruct->mode = (*env)->GetIntField(env, lpObject, XFocusChangeEventFc.mode);
	return lpStruct;
}

void setXFocusChangeEventFields(JNIEnv *env, jobject lpObject, XFocusChangeEvent *lpStruct)
{
	if (!XFocusChangeEventFc.cached) cacheXFocusChangeEventFields(env, lpObject);
	setXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, XFocusChangeEventFc.detail, (jint)lpStruct->detail);
	(*env)->SetIntField(env, lpObject, XFocusChangeEventFc.mode, (jint)lpStruct->mode);
}
#endif

#ifndef NO_XRenderPictureAttributes
typedef struct XRenderPictureAttributes_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID component_alpha, dither, poly_mode, poly_edge, subwindow_mode, graphics_exposures, clip_mask, clip_y_origin, clip_x_origin, alpha_y_origin, alpha_x_origin, alpha_map, repeat;
} XRenderPictureAttributes_FID_CACHE;

XRenderPictureAttributes_FID_CACHE XRenderPictureAttributesFc;

void cacheXRenderPictureAttributesFields(JNIEnv *env, jobject lpObject)
{
	if (XRenderPictureAttributesFc.cached) return;
	XRenderPictureAttributesFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XRenderPictureAttributesFc.component_alpha = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "component_alpha", "Z");
	XRenderPictureAttributesFc.dither = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "dither", "J");
	XRenderPictureAttributesFc.poly_mode = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "poly_mode", "I");
	XRenderPictureAttributesFc.poly_edge = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "poly_edge", "I");
	XRenderPictureAttributesFc.subwindow_mode = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "subwindow_mode", "I");
	XRenderPictureAttributesFc.graphics_exposures = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "graphics_exposures", "Z");
	XRenderPictureAttributesFc.clip_mask = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "clip_mask", "J");
	XRenderPictureAttributesFc.clip_y_origin = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "clip_y_origin", "I");
	XRenderPictureAttributesFc.clip_x_origin = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "clip_x_origin", "I");
	XRenderPictureAttributesFc.alpha_y_origin = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "alpha_y_origin", "I");
	XRenderPictureAttributesFc.alpha_x_origin = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "alpha_x_origin", "I");
	XRenderPictureAttributesFc.alpha_map = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "alpha_map", "J");
	XRenderPictureAttributesFc.repeat = (*env)->GetFieldID(env, XRenderPictureAttributesFc.clazz, "repeat", "Z");
	XRenderPictureAttributesFc.cached = 1;
}

XRenderPictureAttributes *getXRenderPictureAttributesFields(JNIEnv *env, jobject lpObject, XRenderPictureAttributes *lpStruct)
{
	if (!XRenderPictureAttributesFc.cached) cacheXRenderPictureAttributesFields(env, lpObject);
	lpStruct->component_alpha = (*env)->GetBooleanField(env, lpObject, XRenderPictureAttributesFc.component_alpha);
	lpStruct->dither = (*env)->GetLongField(env, lpObject, XRenderPictureAttributesFc.dither);
	lpStruct->poly_mode = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.poly_mode);
	lpStruct->poly_edge = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.poly_edge);
	lpStruct->subwindow_mode = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.subwindow_mode);
	lpStruct->graphics_exposures = (*env)->GetBooleanField(env, lpObject, XRenderPictureAttributesFc.graphics_exposures);
	lpStruct->clip_mask = (*env)->GetLongField(env, lpObject, XRenderPictureAttributesFc.clip_mask);
	lpStruct->clip_y_origin = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.clip_y_origin);
	lpStruct->clip_x_origin = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.clip_x_origin);
	lpStruct->alpha_y_origin = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.alpha_y_origin);
	lpStruct->alpha_x_origin = (*env)->GetIntField(env, lpObject, XRenderPictureAttributesFc.alpha_x_origin);
	lpStruct->alpha_map = (*env)->GetLongField(env, lpObject, XRenderPictureAttributesFc.alpha_map);
	lpStruct->repeat = (*env)->GetBooleanField(env, lpObject, XRenderPictureAttributesFc.repeat);
	return lpStruct;
}

void setXRenderPictureAttributesFields(JNIEnv *env, jobject lpObject, XRenderPictureAttributes *lpStruct)
{
	if (!XRenderPictureAttributesFc.cached) cacheXRenderPictureAttributesFields(env, lpObject);
	(*env)->SetBooleanField(env, lpObject, XRenderPictureAttributesFc.component_alpha, (jboolean)lpStruct->component_alpha);
	(*env)->SetLongField(env, lpObject, XRenderPictureAttributesFc.dither, (jlong)lpStruct->dither);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.poly_mode, (jint)lpStruct->poly_mode);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.poly_edge, (jint)lpStruct->poly_edge);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.subwindow_mode, (jint)lpStruct->subwindow_mode);
	(*env)->SetBooleanField(env, lpObject, XRenderPictureAttributesFc.graphics_exposures, (jboolean)lpStruct->graphics_exposures);
	(*env)->SetLongField(env, lpObject, XRenderPictureAttributesFc.clip_mask, (jlong)lpStruct->clip_mask);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.clip_y_origin, (jint)lpStruct->clip_y_origin);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.clip_x_origin, (jint)lpStruct->clip_x_origin);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.alpha_y_origin, (jint)lpStruct->alpha_y_origin);
	(*env)->SetIntField(env, lpObject, XRenderPictureAttributesFc.alpha_x_origin, (jint)lpStruct->alpha_x_origin);
	(*env)->SetLongField(env, lpObject, XRenderPictureAttributesFc.alpha_map, (jlong)lpStruct->alpha_map);
	(*env)->SetBooleanField(env, lpObject, XRenderPictureAttributesFc.repeat, (jboolean)lpStruct->repeat);
}
#endif

#ifndef NO_XVisibilityEvent
typedef struct XVisibilityEvent_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID state;
} XVisibilityEvent_FID_CACHE;

XVisibilityEvent_FID_CACHE XVisibilityEventFc;

void cacheXVisibilityEventFields(JNIEnv *env, jobject lpObject)
{
	if (XVisibilityEventFc.cached) return;
	cacheXAnyEventFields(env, lpObject);
	XVisibilityEventFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XVisibilityEventFc.state = (*env)->GetFieldID(env, XVisibilityEventFc.clazz, "state", "I");
	XVisibilityEventFc.cached = 1;
}

XVisibilityEvent *getXVisibilityEventFields(JNIEnv *env, jobject lpObject, XVisibilityEvent *lpStruct)
{
	if (!XVisibilityEventFc.cached) cacheXVisibilityEventFields(env, lpObject);
	getXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	lpStruct->state = (*env)->GetIntField(env, lpObject, XVisibilityEventFc.state);
	return lpStruct;
}

void setXVisibilityEventFields(JNIEnv *env, jobject lpObject, XVisibilityEvent *lpStruct)
{
	if (!XVisibilityEventFc.cached) cacheXVisibilityEventFields(env, lpObject);
	setXAnyEventFields(env, lpObject, (XAnyEvent *)lpStruct);
	(*env)->SetIntField(env, lpObject, XVisibilityEventFc.state, (jint)lpStruct->state);
}
#endif

#ifndef NO_XWindowChanges
typedef struct XWindowChanges_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID stack_mode, sibling, border_width, height, width, y, x;
} XWindowChanges_FID_CACHE;

XWindowChanges_FID_CACHE XWindowChangesFc;

void cacheXWindowChangesFields(JNIEnv *env, jobject lpObject)
{
	if (XWindowChangesFc.cached) return;
	XWindowChangesFc.clazz = (*env)->GetObjectClass(env, lpObject);
	XWindowChangesFc.stack_mode = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "stack_mode", "I");
	XWindowChangesFc.sibling = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "sibling", "J");
	XWindowChangesFc.border_width = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "border_width", "I");
	XWindowChangesFc.height = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "height", "I");
	XWindowChangesFc.width = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "width", "I");
	XWindowChangesFc.y = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "y", "I");
	XWindowChangesFc.x = (*env)->GetFieldID(env, XWindowChangesFc.clazz, "x", "I");
	XWindowChangesFc.cached = 1;
}

XWindowChanges *getXWindowChangesFields(JNIEnv *env, jobject lpObject, XWindowChanges *lpStruct)
{
	if (!XWindowChangesFc.cached) cacheXWindowChangesFields(env, lpObject);
	lpStruct->stack_mode = (*env)->GetIntField(env, lpObject, XWindowChangesFc.stack_mode);
	lpStruct->sibling = (*env)->GetLongField(env, lpObject, XWindowChangesFc.sibling);
	lpStruct->border_width = (*env)->GetIntField(env, lpObject, XWindowChangesFc.border_width);
	lpStruct->height = (*env)->GetIntField(env, lpObject, XWindowChangesFc.height);
	lpStruct->width = (*env)->GetIntField(env, lpObject, XWindowChangesFc.width);
	lpStruct->y = (*env)->GetIntField(env, lpObject, XWindowChangesFc.y);
	lpStruct->x = (*env)->GetIntField(env, lpObject, XWindowChangesFc.x);
	return lpStruct;
}

void setXWindowChangesFields(JNIEnv *env, jobject lpObject, XWindowChanges *lpStruct)
{
	if (!XWindowChangesFc.cached) cacheXWindowChangesFields(env, lpObject);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.stack_mode, (jint)lpStruct->stack_mode);
	(*env)->SetLongField(env, lpObject, XWindowChangesFc.sibling, (jlong)lpStruct->sibling);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.border_width, (jint)lpStruct->border_width);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.height, (jint)lpStruct->height);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.width, (jint)lpStruct->width);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.y, (jint)lpStruct->y);
	(*env)->SetIntField(env, lpObject, XWindowChangesFc.x, (jint)lpStruct->x);
}
#endif

