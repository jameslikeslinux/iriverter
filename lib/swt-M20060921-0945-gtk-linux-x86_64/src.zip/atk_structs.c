/*******************************************************************************
 * Copyright (c) 2000, 2006 IBM Corporation and others. All rights reserved.
 * The contents of this file are made available under the terms
 * of the GNU Lesser General Public License (LGPL) Version 2.1 that
 * accompanies this distribution (lgpl-v21.txt).  The LGPL is also
 * available at http://www.gnu.org/licenses/lgpl.html.  If the version
 * of the LGPL at http://www.gnu.org is different to the version of
 * the LGPL accompanying this distribution and there is any conflict
 * between the two license versions, the terms of the LGPL accompanying
 * this distribution shall govern.
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

#include "swt.h"
#include "atk_structs.h"

#ifndef NO_AtkActionIface
typedef struct AtkActionIface_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID set_description, get_keybinding, get_name, get_description, get_n_actions, do_action;
} AtkActionIface_FID_CACHE;

AtkActionIface_FID_CACHE AtkActionIfaceFc;

void cacheAtkActionIfaceFields(JNIEnv *env, jobject lpObject)
{
	if (AtkActionIfaceFc.cached) return;
	AtkActionIfaceFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkActionIfaceFc.set_description = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "set_description", "J");
	AtkActionIfaceFc.get_keybinding = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "get_keybinding", "J");
	AtkActionIfaceFc.get_name = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "get_name", "J");
	AtkActionIfaceFc.get_description = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "get_description", "J");
	AtkActionIfaceFc.get_n_actions = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "get_n_actions", "J");
	AtkActionIfaceFc.do_action = (*env)->GetFieldID(env, AtkActionIfaceFc.clazz, "do_action", "J");
	AtkActionIfaceFc.cached = 1;
}

AtkActionIface *getAtkActionIfaceFields(JNIEnv *env, jobject lpObject, AtkActionIface *lpStruct)
{
	if (!AtkActionIfaceFc.cached) cacheAtkActionIfaceFields(env, lpObject);
	lpStruct->set_description = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.set_description);
	lpStruct->get_keybinding = (G_CONST_RETURN gchar *(*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.get_keybinding);
	lpStruct->get_name = (G_CONST_RETURN gchar *(*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.get_name);
	lpStruct->get_description = (G_CONST_RETURN gchar *(*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.get_description);
	lpStruct->get_n_actions = (gint (*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.get_n_actions);
	lpStruct->do_action = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkActionIfaceFc.do_action);
	return lpStruct;
}

void setAtkActionIfaceFields(JNIEnv *env, jobject lpObject, AtkActionIface *lpStruct)
{
	if (!AtkActionIfaceFc.cached) cacheAtkActionIfaceFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.set_description, (jlong)lpStruct->set_description);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.get_keybinding, (jlong)lpStruct->get_keybinding);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.get_name, (jlong)lpStruct->get_name);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.get_description, (jlong)lpStruct->get_description);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.get_n_actions, (jlong)lpStruct->get_n_actions);
	(*env)->SetLongField(env, lpObject, AtkActionIfaceFc.do_action, (jlong)lpStruct->do_action);
}
#endif

#ifndef NO_AtkComponentIface
typedef struct AtkComponentIface_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID get_mdi_zorder, get_layer, set_size, set_position, set_extents, remove_focus_handler, grab_focus, get_size, get_position, get_extents, ref_accessible_at_point, contains, add_focus_handler;
} AtkComponentIface_FID_CACHE;

AtkComponentIface_FID_CACHE AtkComponentIfaceFc;

void cacheAtkComponentIfaceFields(JNIEnv *env, jobject lpObject)
{
	if (AtkComponentIfaceFc.cached) return;
	AtkComponentIfaceFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkComponentIfaceFc.get_mdi_zorder = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "get_mdi_zorder", "J");
	AtkComponentIfaceFc.get_layer = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "get_layer", "J");
	AtkComponentIfaceFc.set_size = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "set_size", "J");
	AtkComponentIfaceFc.set_position = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "set_position", "J");
	AtkComponentIfaceFc.set_extents = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "set_extents", "J");
	AtkComponentIfaceFc.remove_focus_handler = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "remove_focus_handler", "J");
	AtkComponentIfaceFc.grab_focus = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "grab_focus", "J");
	AtkComponentIfaceFc.get_size = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "get_size", "J");
	AtkComponentIfaceFc.get_position = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "get_position", "J");
	AtkComponentIfaceFc.get_extents = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "get_extents", "J");
	AtkComponentIfaceFc.ref_accessible_at_point = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "ref_accessible_at_point", "J");
	AtkComponentIfaceFc.contains = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "contains", "J");
	AtkComponentIfaceFc.add_focus_handler = (*env)->GetFieldID(env, AtkComponentIfaceFc.clazz, "add_focus_handler", "J");
	AtkComponentIfaceFc.cached = 1;
}

AtkComponentIface *getAtkComponentIfaceFields(JNIEnv *env, jobject lpObject, AtkComponentIface *lpStruct)
{
	if (!AtkComponentIfaceFc.cached) cacheAtkComponentIfaceFields(env, lpObject);
	lpStruct->get_mdi_zorder = (gint (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.get_mdi_zorder);
	lpStruct->get_layer = (AtkLayer (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.get_layer);
	lpStruct->set_size = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.set_size);
	lpStruct->set_position = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.set_position);
	lpStruct->set_extents = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.set_extents);
	lpStruct->remove_focus_handler = (void (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.remove_focus_handler);
	lpStruct->grab_focus = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.grab_focus);
	lpStruct->get_size = (void (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.get_size);
	lpStruct->get_position = (void (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.get_position);
	lpStruct->get_extents = (void (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.get_extents);
	lpStruct->ref_accessible_at_point = (AtkObject *(*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.ref_accessible_at_point);
	lpStruct->contains = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.contains);
	lpStruct->add_focus_handler = (guint (*)())(*env)->GetLongField(env, lpObject, AtkComponentIfaceFc.add_focus_handler);
	return lpStruct;
}

void setAtkComponentIfaceFields(JNIEnv *env, jobject lpObject, AtkComponentIface *lpStruct)
{
	if (!AtkComponentIfaceFc.cached) cacheAtkComponentIfaceFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.get_mdi_zorder, (jlong)lpStruct->get_mdi_zorder);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.get_layer, (jlong)lpStruct->get_layer);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.set_size, (jlong)lpStruct->set_size);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.set_position, (jlong)lpStruct->set_position);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.set_extents, (jlong)lpStruct->set_extents);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.remove_focus_handler, (jlong)lpStruct->remove_focus_handler);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.grab_focus, (jlong)lpStruct->grab_focus);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.get_size, (jlong)lpStruct->get_size);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.get_position, (jlong)lpStruct->get_position);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.get_extents, (jlong)lpStruct->get_extents);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.ref_accessible_at_point, (jlong)lpStruct->ref_accessible_at_point);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.contains, (jlong)lpStruct->contains);
	(*env)->SetLongField(env, lpObject, AtkComponentIfaceFc.add_focus_handler, (jlong)lpStruct->add_focus_handler);
}
#endif

#ifndef NO_AtkHypertextIface
typedef struct AtkHypertextIface_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID get_link_index, get_n_links, get_link;
} AtkHypertextIface_FID_CACHE;

AtkHypertextIface_FID_CACHE AtkHypertextIfaceFc;

void cacheAtkHypertextIfaceFields(JNIEnv *env, jobject lpObject)
{
	if (AtkHypertextIfaceFc.cached) return;
	AtkHypertextIfaceFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkHypertextIfaceFc.get_link_index = (*env)->GetFieldID(env, AtkHypertextIfaceFc.clazz, "get_link_index", "J");
	AtkHypertextIfaceFc.get_n_links = (*env)->GetFieldID(env, AtkHypertextIfaceFc.clazz, "get_n_links", "J");
	AtkHypertextIfaceFc.get_link = (*env)->GetFieldID(env, AtkHypertextIfaceFc.clazz, "get_link", "J");
	AtkHypertextIfaceFc.cached = 1;
}

AtkHypertextIface *getAtkHypertextIfaceFields(JNIEnv *env, jobject lpObject, AtkHypertextIface *lpStruct)
{
	if (!AtkHypertextIfaceFc.cached) cacheAtkHypertextIfaceFields(env, lpObject);
	lpStruct->get_link_index = (gint (*)())(*env)->GetLongField(env, lpObject, AtkHypertextIfaceFc.get_link_index);
	lpStruct->get_n_links = (gint (*)())(*env)->GetLongField(env, lpObject, AtkHypertextIfaceFc.get_n_links);
	lpStruct->get_link = (AtkHyperlink *(*)())(*env)->GetLongField(env, lpObject, AtkHypertextIfaceFc.get_link);
	return lpStruct;
}

void setAtkHypertextIfaceFields(JNIEnv *env, jobject lpObject, AtkHypertextIface *lpStruct)
{
	if (!AtkHypertextIfaceFc.cached) cacheAtkHypertextIfaceFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkHypertextIfaceFc.get_link_index, (jlong)lpStruct->get_link_index);
	(*env)->SetLongField(env, lpObject, AtkHypertextIfaceFc.get_n_links, (jlong)lpStruct->get_n_links);
	(*env)->SetLongField(env, lpObject, AtkHypertextIfaceFc.get_link, (jlong)lpStruct->get_link);
}
#endif

#ifndef NO_AtkObjectClass
typedef struct AtkObjectClass_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID visible_data_changed, state_change, property_change, focus_event, children_changed, initialize, remove_property_change_handler, connect_property_change_handler, set_role, set_parent, set_description, set_name, ref_state_set, get_mdi_zorder, get_layer, get_role, ref_relation_set, get_index_in_parent, ref_child, get_n_children, get_parent, get_description, get_name;
} AtkObjectClass_FID_CACHE;

AtkObjectClass_FID_CACHE AtkObjectClassFc;

void cacheAtkObjectClassFields(JNIEnv *env, jobject lpObject)
{
	if (AtkObjectClassFc.cached) return;
	AtkObjectClassFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkObjectClassFc.visible_data_changed = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "visible_data_changed", "J");
	AtkObjectClassFc.state_change = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "state_change", "J");
	AtkObjectClassFc.property_change = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "property_change", "J");
	AtkObjectClassFc.focus_event = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "focus_event", "J");
	AtkObjectClassFc.children_changed = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "children_changed", "J");
	AtkObjectClassFc.initialize = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "initialize", "J");
	AtkObjectClassFc.remove_property_change_handler = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "remove_property_change_handler", "J");
	AtkObjectClassFc.connect_property_change_handler = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "connect_property_change_handler", "J");
	AtkObjectClassFc.set_role = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "set_role", "J");
	AtkObjectClassFc.set_parent = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "set_parent", "J");
	AtkObjectClassFc.set_description = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "set_description", "J");
	AtkObjectClassFc.set_name = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "set_name", "J");
	AtkObjectClassFc.ref_state_set = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "ref_state_set", "J");
	AtkObjectClassFc.get_mdi_zorder = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_mdi_zorder", "J");
	AtkObjectClassFc.get_layer = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_layer", "J");
	AtkObjectClassFc.get_role = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_role", "J");
	AtkObjectClassFc.ref_relation_set = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "ref_relation_set", "J");
	AtkObjectClassFc.get_index_in_parent = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_index_in_parent", "J");
	AtkObjectClassFc.ref_child = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "ref_child", "J");
	AtkObjectClassFc.get_n_children = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_n_children", "J");
	AtkObjectClassFc.get_parent = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_parent", "J");
	AtkObjectClassFc.get_description = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_description", "J");
	AtkObjectClassFc.get_name = (*env)->GetFieldID(env, AtkObjectClassFc.clazz, "get_name", "J");
	AtkObjectClassFc.cached = 1;
}

AtkObjectClass *getAtkObjectClassFields(JNIEnv *env, jobject lpObject, AtkObjectClass *lpStruct)
{
	if (!AtkObjectClassFc.cached) cacheAtkObjectClassFields(env, lpObject);
	lpStruct->visible_data_changed = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.visible_data_changed);
	lpStruct->state_change = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.state_change);
	lpStruct->property_change = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.property_change);
	lpStruct->focus_event = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.focus_event);
	lpStruct->children_changed = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.children_changed);
	lpStruct->initialize = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.initialize);
	lpStruct->remove_property_change_handler = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.remove_property_change_handler);
	lpStruct->connect_property_change_handler = (guint (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.connect_property_change_handler);
	lpStruct->set_role = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.set_role);
	lpStruct->set_parent = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.set_parent);
	lpStruct->set_description = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.set_description);
	lpStruct->set_name = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.set_name);
	lpStruct->ref_state_set = (AtkStateSet *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.ref_state_set);
	lpStruct->get_mdi_zorder = (gint (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_mdi_zorder);
	lpStruct->get_layer = (AtkLayer (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_layer);
	lpStruct->get_role = (AtkRole (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_role);
	lpStruct->ref_relation_set = (AtkRelationSet *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.ref_relation_set);
	lpStruct->get_index_in_parent = (gint (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_index_in_parent);
	lpStruct->ref_child = (AtkObject *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.ref_child);
	lpStruct->get_n_children = (gint (*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_n_children);
	lpStruct->get_parent = (AtkObject *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_parent);
	lpStruct->get_description = (G_CONST_RETURN gchar *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_description);
	lpStruct->get_name = (G_CONST_RETURN gchar *(*)())(*env)->GetLongField(env, lpObject, AtkObjectClassFc.get_name);
	return lpStruct;
}

void setAtkObjectClassFields(JNIEnv *env, jobject lpObject, AtkObjectClass *lpStruct)
{
	if (!AtkObjectClassFc.cached) cacheAtkObjectClassFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.visible_data_changed, (jlong)lpStruct->visible_data_changed);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.state_change, (jlong)lpStruct->state_change);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.property_change, (jlong)lpStruct->property_change);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.focus_event, (jlong)lpStruct->focus_event);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.children_changed, (jlong)lpStruct->children_changed);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.initialize, (jlong)lpStruct->initialize);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.remove_property_change_handler, (jlong)lpStruct->remove_property_change_handler);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.connect_property_change_handler, (jlong)lpStruct->connect_property_change_handler);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.set_role, (jlong)lpStruct->set_role);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.set_parent, (jlong)lpStruct->set_parent);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.set_description, (jlong)lpStruct->set_description);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.set_name, (jlong)lpStruct->set_name);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.ref_state_set, (jlong)lpStruct->ref_state_set);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_mdi_zorder, (jlong)lpStruct->get_mdi_zorder);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_layer, (jlong)lpStruct->get_layer);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_role, (jlong)lpStruct->get_role);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.ref_relation_set, (jlong)lpStruct->ref_relation_set);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_index_in_parent, (jlong)lpStruct->get_index_in_parent);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.ref_child, (jlong)lpStruct->ref_child);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_n_children, (jlong)lpStruct->get_n_children);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_parent, (jlong)lpStruct->get_parent);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_description, (jlong)lpStruct->get_description);
	(*env)->SetLongField(env, lpObject, AtkObjectClassFc.get_name, (jlong)lpStruct->get_name);
}
#endif

#ifndef NO_AtkObjectFactoryClass
typedef struct AtkObjectFactoryClass_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID get_accessible_type, invalidate, create_accessible;
} AtkObjectFactoryClass_FID_CACHE;

AtkObjectFactoryClass_FID_CACHE AtkObjectFactoryClassFc;

void cacheAtkObjectFactoryClassFields(JNIEnv *env, jobject lpObject)
{
	if (AtkObjectFactoryClassFc.cached) return;
	AtkObjectFactoryClassFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkObjectFactoryClassFc.get_accessible_type = (*env)->GetFieldID(env, AtkObjectFactoryClassFc.clazz, "get_accessible_type", "J");
	AtkObjectFactoryClassFc.invalidate = (*env)->GetFieldID(env, AtkObjectFactoryClassFc.clazz, "invalidate", "J");
	AtkObjectFactoryClassFc.create_accessible = (*env)->GetFieldID(env, AtkObjectFactoryClassFc.clazz, "create_accessible", "J");
	AtkObjectFactoryClassFc.cached = 1;
}

AtkObjectFactoryClass *getAtkObjectFactoryClassFields(JNIEnv *env, jobject lpObject, AtkObjectFactoryClass *lpStruct)
{
	if (!AtkObjectFactoryClassFc.cached) cacheAtkObjectFactoryClassFields(env, lpObject);
	lpStruct->get_accessible_type = (GType (*)())(*env)->GetLongField(env, lpObject, AtkObjectFactoryClassFc.get_accessible_type);
	lpStruct->invalidate = (void (*)())(*env)->GetLongField(env, lpObject, AtkObjectFactoryClassFc.invalidate);
	lpStruct->create_accessible = (AtkObject *(*)())(*env)->GetLongField(env, lpObject, AtkObjectFactoryClassFc.create_accessible);
	return lpStruct;
}

void setAtkObjectFactoryClassFields(JNIEnv *env, jobject lpObject, AtkObjectFactoryClass *lpStruct)
{
	if (!AtkObjectFactoryClassFc.cached) cacheAtkObjectFactoryClassFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkObjectFactoryClassFc.get_accessible_type, (jlong)lpStruct->get_accessible_type);
	(*env)->SetLongField(env, lpObject, AtkObjectFactoryClassFc.invalidate, (jlong)lpStruct->invalidate);
	(*env)->SetLongField(env, lpObject, AtkObjectFactoryClassFc.create_accessible, (jlong)lpStruct->create_accessible);
}
#endif

#ifndef NO_AtkSelectionIface
typedef struct AtkSelectionIface_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID selection_changed, select_all_selection, remove_selection, is_child_selected, get_selection_count, ref_selection, clear_selection, add_selection;
} AtkSelectionIface_FID_CACHE;

AtkSelectionIface_FID_CACHE AtkSelectionIfaceFc;

void cacheAtkSelectionIfaceFields(JNIEnv *env, jobject lpObject)
{
	if (AtkSelectionIfaceFc.cached) return;
	AtkSelectionIfaceFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkSelectionIfaceFc.selection_changed = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "selection_changed", "J");
	AtkSelectionIfaceFc.select_all_selection = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "select_all_selection", "J");
	AtkSelectionIfaceFc.remove_selection = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "remove_selection", "J");
	AtkSelectionIfaceFc.is_child_selected = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "is_child_selected", "J");
	AtkSelectionIfaceFc.get_selection_count = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "get_selection_count", "J");
	AtkSelectionIfaceFc.ref_selection = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "ref_selection", "J");
	AtkSelectionIfaceFc.clear_selection = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "clear_selection", "J");
	AtkSelectionIfaceFc.add_selection = (*env)->GetFieldID(env, AtkSelectionIfaceFc.clazz, "add_selection", "J");
	AtkSelectionIfaceFc.cached = 1;
}

AtkSelectionIface *getAtkSelectionIfaceFields(JNIEnv *env, jobject lpObject, AtkSelectionIface *lpStruct)
{
	if (!AtkSelectionIfaceFc.cached) cacheAtkSelectionIfaceFields(env, lpObject);
	lpStruct->selection_changed = (void (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.selection_changed);
	lpStruct->select_all_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.select_all_selection);
	lpStruct->remove_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.remove_selection);
	lpStruct->is_child_selected = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.is_child_selected);
	lpStruct->get_selection_count = (gint (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.get_selection_count);
	lpStruct->ref_selection = (AtkObject *(*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.ref_selection);
	lpStruct->clear_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.clear_selection);
	lpStruct->add_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkSelectionIfaceFc.add_selection);
	return lpStruct;
}

void setAtkSelectionIfaceFields(JNIEnv *env, jobject lpObject, AtkSelectionIface *lpStruct)
{
	if (!AtkSelectionIfaceFc.cached) cacheAtkSelectionIfaceFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.selection_changed, (jlong)lpStruct->selection_changed);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.select_all_selection, (jlong)lpStruct->select_all_selection);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.remove_selection, (jlong)lpStruct->remove_selection);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.is_child_selected, (jlong)lpStruct->is_child_selected);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.get_selection_count, (jlong)lpStruct->get_selection_count);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.ref_selection, (jlong)lpStruct->ref_selection);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.clear_selection, (jlong)lpStruct->clear_selection);
	(*env)->SetLongField(env, lpObject, AtkSelectionIfaceFc.add_selection, (jlong)lpStruct->add_selection);
}
#endif

#ifndef NO_AtkTextIface
typedef struct AtkTextIface_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID text_selection_changed, text_caret_moved, text_changed, set_caret_offset, set_selection, remove_selection, add_selection, get_selection, get_n_selections, get_offset_at_point, get_character_count, get_character_extents, get_default_attributes, get_run_attributes, get_caret_offset, get_text_before_offset, get_character_at_offset, get_text_at_offset, get_text_after_offset, get_text;
} AtkTextIface_FID_CACHE;

AtkTextIface_FID_CACHE AtkTextIfaceFc;

void cacheAtkTextIfaceFields(JNIEnv *env, jobject lpObject)
{
	if (AtkTextIfaceFc.cached) return;
	AtkTextIfaceFc.clazz = (*env)->GetObjectClass(env, lpObject);
	AtkTextIfaceFc.text_selection_changed = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "text_selection_changed", "J");
	AtkTextIfaceFc.text_caret_moved = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "text_caret_moved", "J");
	AtkTextIfaceFc.text_changed = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "text_changed", "J");
	AtkTextIfaceFc.set_caret_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "set_caret_offset", "J");
	AtkTextIfaceFc.set_selection = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "set_selection", "J");
	AtkTextIfaceFc.remove_selection = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "remove_selection", "J");
	AtkTextIfaceFc.add_selection = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "add_selection", "J");
	AtkTextIfaceFc.get_selection = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_selection", "J");
	AtkTextIfaceFc.get_n_selections = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_n_selections", "J");
	AtkTextIfaceFc.get_offset_at_point = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_offset_at_point", "J");
	AtkTextIfaceFc.get_character_count = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_character_count", "J");
	AtkTextIfaceFc.get_character_extents = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_character_extents", "J");
	AtkTextIfaceFc.get_default_attributes = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_default_attributes", "J");
	AtkTextIfaceFc.get_run_attributes = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_run_attributes", "J");
	AtkTextIfaceFc.get_caret_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_caret_offset", "J");
	AtkTextIfaceFc.get_text_before_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_text_before_offset", "J");
	AtkTextIfaceFc.get_character_at_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_character_at_offset", "J");
	AtkTextIfaceFc.get_text_at_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_text_at_offset", "J");
	AtkTextIfaceFc.get_text_after_offset = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_text_after_offset", "J");
	AtkTextIfaceFc.get_text = (*env)->GetFieldID(env, AtkTextIfaceFc.clazz, "get_text", "J");
	AtkTextIfaceFc.cached = 1;
}

AtkTextIface *getAtkTextIfaceFields(JNIEnv *env, jobject lpObject, AtkTextIface *lpStruct)
{
	if (!AtkTextIfaceFc.cached) cacheAtkTextIfaceFields(env, lpObject);
	lpStruct->text_selection_changed = (void (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.text_selection_changed);
	lpStruct->text_caret_moved = (void (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.text_caret_moved);
	lpStruct->text_changed = (void (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.text_changed);
	lpStruct->set_caret_offset = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.set_caret_offset);
	lpStruct->set_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.set_selection);
	lpStruct->remove_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.remove_selection);
	lpStruct->add_selection = (gboolean (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.add_selection);
	lpStruct->get_selection = (gchar *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_selection);
	lpStruct->get_n_selections = (gint (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_n_selections);
	lpStruct->get_offset_at_point = (gint (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_offset_at_point);
	lpStruct->get_character_count = (gint (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_character_count);
	lpStruct->get_character_extents = (void (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_character_extents);
	lpStruct->get_default_attributes = (AtkAttributeSet *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_default_attributes);
	lpStruct->get_run_attributes = (AtkAttributeSet *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_run_attributes);
	lpStruct->get_caret_offset = (gint (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_caret_offset);
	lpStruct->get_text_before_offset = (gchar *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_text_before_offset);
	lpStruct->get_character_at_offset = (gunichar (*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_character_at_offset);
	lpStruct->get_text_at_offset = (gchar *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_text_at_offset);
	lpStruct->get_text_after_offset = (gchar *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_text_after_offset);
	lpStruct->get_text = (gchar *(*)())(*env)->GetLongField(env, lpObject, AtkTextIfaceFc.get_text);
	return lpStruct;
}

void setAtkTextIfaceFields(JNIEnv *env, jobject lpObject, AtkTextIface *lpStruct)
{
	if (!AtkTextIfaceFc.cached) cacheAtkTextIfaceFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.text_selection_changed, (jlong)lpStruct->text_selection_changed);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.text_caret_moved, (jlong)lpStruct->text_caret_moved);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.text_changed, (jlong)lpStruct->text_changed);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.set_caret_offset, (jlong)lpStruct->set_caret_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.set_selection, (jlong)lpStruct->set_selection);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.remove_selection, (jlong)lpStruct->remove_selection);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.add_selection, (jlong)lpStruct->add_selection);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_selection, (jlong)lpStruct->get_selection);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_n_selections, (jlong)lpStruct->get_n_selections);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_offset_at_point, (jlong)lpStruct->get_offset_at_point);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_character_count, (jlong)lpStruct->get_character_count);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_character_extents, (jlong)lpStruct->get_character_extents);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_default_attributes, (jlong)lpStruct->get_default_attributes);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_run_attributes, (jlong)lpStruct->get_run_attributes);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_caret_offset, (jlong)lpStruct->get_caret_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_text_before_offset, (jlong)lpStruct->get_text_before_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_character_at_offset, (jlong)lpStruct->get_character_at_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_text_at_offset, (jlong)lpStruct->get_text_at_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_text_after_offset, (jlong)lpStruct->get_text_after_offset);
	(*env)->SetLongField(env, lpObject, AtkTextIfaceFc.get_text, (jlong)lpStruct->get_text);
}
#endif

#ifndef NO_GtkAccessible
typedef struct GtkAccessible_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID widget;
} GtkAccessible_FID_CACHE;

GtkAccessible_FID_CACHE GtkAccessibleFc;

void cacheGtkAccessibleFields(JNIEnv *env, jobject lpObject)
{
	if (GtkAccessibleFc.cached) return;
	GtkAccessibleFc.clazz = (*env)->GetObjectClass(env, lpObject);
	GtkAccessibleFc.widget = (*env)->GetFieldID(env, GtkAccessibleFc.clazz, "widget", "J");
	GtkAccessibleFc.cached = 1;
}

GtkAccessible *getGtkAccessibleFields(JNIEnv *env, jobject lpObject, GtkAccessible *lpStruct)
{
	if (!GtkAccessibleFc.cached) cacheGtkAccessibleFields(env, lpObject);
	lpStruct->widget = (GtkWidget *)(*env)->GetLongField(env, lpObject, GtkAccessibleFc.widget);
	return lpStruct;
}

void setGtkAccessibleFields(JNIEnv *env, jobject lpObject, GtkAccessible *lpStruct)
{
	if (!GtkAccessibleFc.cached) cacheGtkAccessibleFields(env, lpObject);
	(*env)->SetLongField(env, lpObject, GtkAccessibleFc.widget, (jlong)lpStruct->widget);
}
#endif

